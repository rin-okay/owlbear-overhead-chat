# Discord Arrivals for Owlbear Rodeo

Discord Arrivals gives new players an optional Discord sign-in after they enter an Owlbear room. It creates a one-grid-space character token from their Discord avatar, assigns control to their Owlbear identity, places it at the scene's GM-defined spawn point, and selects it as their Overhead Chat avatar. It installs independently of Overhead Chat.

## Deploy

1. In the [Discord Developer Portal](https://discord.com/developers/applications), create an application. In OAuth2 settings, copy its client ID and register your deployment's exact callback URL, for example `https://owlbear-discord-arrivals.example.workers.dev/oauth/callback`. The extension asks for the `identify` scope.
2. Install Node.js and sign into Cloudflare with `npx wrangler login`. In this directory, edit `wrangler.toml`. Enter the Discord client ID and the HTTPS origin of your Cloudflare Worker. Keep the origin free of a trailing slash.
3. Run these commands in the package directory. Paste the Discord client secret at the first secret prompt. At the second prompt, enter a strong random secret of at least 32 characters. Keep the signing secret stable because it also determines the room-specific identity used to look up a returning player's token.

   ```sh
   npx wrangler deploy
   npx wrangler secret put DISCORD_CLIENT_SECRET
   npx wrangler secret put SIGNING_SECRET
   ```

4. Add `https://rin-okay.github.io/owlbear-overhead-chat/discord-arrivals/manifest.json` to Owlbear's custom extensions and enable Discord Arrivals in your room.
5. In the Discord Arrivals GM panel, enter the deployed Cloudflare Worker address before enabling arrivals. The package's `FRONTEND_ORIGIN` already points to `https://rin-okay.github.io`.

GitHub Pages serves the extension. The Worker handles OAuth. To serve both from the Worker, set `FRONTEND_ORIGIN` to your Worker origin and install from that origin's `/manifest.json` instead. Discord access tokens stay on the Worker during sign-in. The extension stores a room-specific profile identifier and token ID in Owlbear room metadata. The image and display name are visible with the token. The Worker uses Discord's profile image URL, so a player replacing or removing their Discord avatar can affect availability of the original image.

## Set up a scene

1. Put a marker at the desired entry point and select it. Open Discord Arrivals and click **set spawn from selected item**. The extension saves the marker's position. You can remove the marker after saving.
2. Pick a vision mode, check **offer discord sign-in in this scene**, and click **save scene settings**.
3. Enable **Character Update** in Owlbear's player permissions. Enable **Owner Only** if players should control only their own characters. The extension need not grant general character creation permission to players.

A GM must be connected with the destination scene open to create the token. The player can skip the welcome prompt and open Discord Arrivals later. If the browser blocks the popup or the callback cannot talk back to the Owlbear window, use **paste a sign-in code**. The code is tied to the current Owlbear connection. Sign in again after switching tabs to a new Owlbear connection or after the code expires.

Signing in again with the same Discord account reuses its existing token in the active scene. Rejoining with the same Owlbear identity suppresses the prompt. If a guest returns as a new Owlbear identity, they can connect Discord again to reclaim their token once the previous Owlbear identity is disconnected. The extension leaves the token in place on subsequent joins. The spawn point applies when a token is first created in that scene. A linked player can open the panel manually to provision a token in another configured scene.

## Vision modes

| Mode | Behavior |
|---|---|
| Smoke & Spectre scene defaults | After creation the GM gets a prompt to use **Enable Vision** on the token. Smoke & Spectre then applies its own scene defaults. |
| Smoke & Spectre template | Experimental. Enable vision on a spare character with the desired settings, select it, and save it as the template. Only recognized Smoke metadata keys are copied. Use a clean template with no linked vision or explicit viewer overrides. Validate with two player clients before using this for private vision. If the installed version doesn't expose recognizable data, switch to the scene-defaults mode. |
| Owlbear native dynamic fog | The extension adds a local light attached to the owned token in that player's client, using the GM's configured radius. Use this with Owlbear-native fog and walls. |
| None | The extension places the token without adding vision. |

## Verification

Run the local tests with `node --test` from this directory. Before using the extension in a live game, use a GM and two player accounts to validate the hosted Discord callback, token control with Owner Only enabled, vision from each player view, and rejoining without an extra token. If Owlbear doesn't retain a programmatic owner assignment in your room, use the token's **Owner** menu and retry setup from the player panel. Smoke & Spectre template behavior depends on the installed extension version.
