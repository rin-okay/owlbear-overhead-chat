import { test } from "node:test";
import assert from "node:assert/strict";
import { createWorker } from "../worker.mjs";
import { ARRIVAL, avatarTokenId } from "../public/model.mjs";
import { planToken } from "../public/provision.mjs";

const origin = "https://arrivals.example";
const env = {
  PUBLIC_ORIGIN:origin, DISCORD_CLIENT_ID:"123456789012345678", DISCORD_CLIENT_SECRET:"fake test secret",
  SIGNING_SECRET:"01234567890123456789012345678901",
  ASSETS:{fetch:async () => new Response("asset")},
};
const context = {room:"room-id", player:"player-id", connection:"connection-id"};
let now = 1000000;
const requests = [];
const worker = createWorker({
  clock: () => now,
  fetchDiscord: async (url, init) => {
    requests.push({url,init});
    if (url.includes("oauth2/token")) return Response.json({access_token:"fake test token"});
    return Response.json({id:"987654321012345678", global_name:"Test <Player>", avatar:null, discriminator:"0"});
  },
});
async function getStart() {
  const start = await worker.fetch(new Request(origin+"/oauth/start?"+new URLSearchParams(context)), env);
  const authorize = new URL(start.headers.get("Location"));
  return { start, authorize, state:authorize.searchParams.get("state"), cookie:start.headers.get("Set-Cookie").split(";")[0] };
}
function callback(state, cookie) {
  return worker.fetch(new Request(origin+"/oauth/callback?"+new URLSearchParams({state,code:"discord-code"}), {
    headers: cookie ? {Cookie:cookie} : {},
  }), env);
}
function verify(ticket, expected = context) {
  return worker.fetch(new Request(origin+"/oauth/verify", {
    method:"POST", body:JSON.stringify({ticket,...expected}),
  }), env);
}

test("OAuth callback binds to the initiating browser and the original Owlbear connection", async () => {
  const {start,authorize,state,cookie} = await getStart();
  assert.equal(start.status,302);
  assert.equal(authorize.searchParams.get("scope"),"identify");
  assert.equal(authorize.searchParams.get("redirect_uri"),origin+"/oauth/callback");
  assert.match(start.headers.get("Set-Cookie"),/Secure; HttpOnly; SameSite=Lax/);
  assert.doesNotMatch(Buffer.from(state.split(".")[0],"base64url").toString(), new RegExp(cookie.split("=")[1]));
  assert.equal((await callback(state)).status,400);
  assert.equal((await callback(state,cookie+"wrong")).status,400);
  assert.equal(requests.length,0);
  const response = await callback(state,cookie);
  assert.equal(response.status,200);
  const page = await response.text();
  const ticket = page.match(/>([\w-]+\.[\w-]{43})<\/textarea>/)[1];
  assert.ok(!page.includes("fake test secret") && !page.includes("fake test token"));
  assert.equal(requests[0].init.body.get("code"),"discord-code");
  assert.equal((await verify(ticket,{...context, connection:"other"})).status,403);
  assert.equal((await verify(ticket,{...context, player:"other"})).status,403);
  assert.equal((await verify(ticket,{...context, room:"other"})).status,403);
  assert.equal((await verify("x"+ticket)).status,403);
  const profile = await (await verify(ticket)).json();
  assert.match(profile.profile,/^[\w-]{43}$/);
  assert.equal(profile.name,"Test <Player>");
  assert.match(profile.avatar,/^https:\/\/cdn\.discordapp\.com\/embed\/avatars\/[0-5]\.png$/);
  now += 901000;
  assert.equal((await verify(ticket)).status,403);
  assert.equal((await callback(state,cookie)).status,400);
});

test("provisioning reuses a Discord token and scopes vision to the GM's chosen mode", async () => {
  const profile = {profile:"stable-profile"};
  const room = "room-id", player = "owlbear-user";
  const config = {enabled:true, spawn:{x:0,y:42}, vision:"smoke-manual"};
  const initial = {room,player,profile,config,items:[],party:[]};
  const first = await planToken(initial);
  assert.equal(first.id,await avatarTokenId(room,profile.profile));
  assert.notEqual(first.id,await avatarTokenId("another-room",profile.profile));
  assert.equal(first.needsVision,true);
  const existing = {id:first.id,type:"IMAGE",layer:"CHARACTER",createdUserId:player,metadata:first.metadata};
  const next = await planToken({...initial,items:[existing]});
  assert.equal(next.existing,existing);
  await assert.rejects(planToken({...initial,player:"new-user",items:[existing],party:[{id:player}]}),/connected player/);
  assert.equal((await planToken({...initial,player:"new-user",items:[existing]})).existing,existing);
  await assert.rejects(planToken({...initial,config:{enabled:true}}),/spawn point/);
  const template = {id:"template",type:"IMAGE",layer:"CHARACTER",
    metadata:{"com.battle-system.smoke/vision":{range:12},"unrelated/key":"private", [ARRIVAL]:"old"}};
  const smoke = await planToken({...initial,config:{...config,vision:"smoke-template",templateId:template.id},items:[template]});
  assert.deepEqual(smoke.metadata["com.battle-system.smoke/vision"],{range:12});
  assert.ok(!("unrelated/key" in smoke.metadata));
  assert.equal(smoke.metadata[ARRIVAL].profile,"stable-profile");
  assert.equal((await planToken({...initial,config:{...config,vision:"smoke-template"}})).needsVision,true);
});

test("the Pages frontend can call the Worker verification endpoint", async () => {
  const allowed = "https://rin-okay.github.io";
  const deployed = {...env, FRONTEND_ORIGIN:allowed};
  const makeRequest = (method, originHeader) => new Request(origin+"/oauth/verify", {
    method, headers:{Origin:originHeader}, ...(method === "POST" ? {body:"{}"} : {}),
  });
  const preflight = await worker.fetch(makeRequest("OPTIONS",allowed),deployed);
  assert.equal(preflight.status,204);
  assert.equal(preflight.headers.get("Access-Control-Allow-Origin"),allowed);
  assert.equal((await worker.fetch(makeRequest("POST",allowed),deployed)).headers.get("Access-Control-Allow-Origin"),allowed);
  assert.equal((await worker.fetch(makeRequest("OPTIONS","https://other.example"),deployed)).status,403);
});

test("GM processing verifies the sender and commits ownership before reporting success", async () => {
  const {readFile} = await import("node:fs/promises");
  const {runInNewContext} = await import("node:vm");
  const model = await import("../public/model.mjs");
  const source = (await readFile(new URL("../public/background.js",import.meta.url),"utf8"))
    .replace(/^import .*;\n/gm,"").replaceAll("import.meta.url", "location.href");
  const items = new Map(), messages = [], roomMetadata = {};
  const config = {enabled:true, spawn:{x:-35,y:70}, vision:"smoke-manual"};
  const players = [{id:"p1", connectionId:"c1", role:"PLAYER"}];
  let verifyCalls = 0, creates = 0;
  const OBR = {
    onReady() {},
    party:{getPlayers:async () => players},
    player:{getRole:async () => "GM"},
    scene:{
      isReady:async () => true,
      getMetadata:async () => ({[model.CONFIG]:config}),
      items:{
        getItems:async (ids) => [...items.values()].filter((item) => !ids || ids.includes(item.id)),
        addItems:async ([item]) => { creates++; items.set(item.id,{...item,createdUserId:"forced-gm"}); },
        updateItems:async ([id], update) => update([items.get(id)]),
      },
    },
    room:{
      id:"room",
      getMetadata:async () => roomMetadata,
      getPermissions:async () => ["CHARACTER_UPDATE","CHARACTER_OWNER_ONLY"],
      setMetadata:async (values) => Object.assign(roomMetadata,values),
    },
    broadcast:{sendMessage:async (channel,data) => messages.push({channel,data})},
    notification:{show:async () => {}},
  };
  const buildImage = (image,grid) => {
    const item = {type:"IMAGE",image,grid};
    const builder = {build:() => item};
    for (const field of ["id","name","layer","position","createdUserId","metadata"]) {
      builder[field] = (value) => { item[field] = value; return builder; };
    }
    return builder;
  };
  const provision = runInNewContext(source+"\nprovision",{
    ...model, OBR, planToken, buildImage, console, AbortSignal, URL, location:{origin,href:origin+"/background.js"},
    fetch:async (_, request) => {
      verifyCalls++;
      const data = JSON.parse(request.body);
      assert.deepEqual([data.room,data.player,data.connection],["room","p1","c1"]);
      return Response.json({profile:"profile",name:"Test",avatar:"https://cdn.discordapp.com/avatar.png"});
    },
  });
  const data = {request:"11111111-1111-1111-1111-111111111111",ticket:"example"};
  await provision({connectionId:"other",data},0);
  assert.equal(verifyCalls,0);
  await provision({connectionId:"c1",data},0);
  assert.equal(messages[0].data.connection,"c1");
  const token = items.get(messages[0].data.tokenId);
  assert.equal(token.createdUserId,"p1");
  assert.deepEqual(token.position,{x:-35,y:70});
  assert.equal(roomMetadata[model.linkKey("p1")].tokenId,token.id);
  await provision({connectionId:"c1",data},0);
  assert.equal(creates,1);
  assert.equal(messages[1].data.tokenId,token.id);
});
