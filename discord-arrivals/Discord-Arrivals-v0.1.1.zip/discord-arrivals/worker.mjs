const encoder = new TextEncoder();
const decoder = new TextDecoder();
const STATE_SECONDS = 600;
const TICKET_SECONDS = 900;
const standardHeaders = {
  "Cache-Control": "no-store",
  "Referrer-Policy": "no-referrer",
  "X-Content-Type-Options": "nosniff",
};
const cleanId = (s) => typeof s === "string" && /^[A-Za-z0-9_:.@-]{1,128}$/.test(s);
const snowflake = (s) => typeof s === "string" && /^[0-9]{16,22}$/.test(s);

function base64(bytes) {
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function fromBase64(value) {
  return Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), (c) => c.charCodeAt(0));
}
async function digest(value) {
  return base64(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))));
}
async function importKey(secret) {
  return crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}
async function seal(key, payload) {
  const body = base64(encoder.encode(JSON.stringify(payload)));
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  return body + "." + base64(new Uint8Array(signature));
}
async function unseal(key, token, kind, now) {
  if (typeof token !== "string" || !/^[\w-]{1,4000}\.[\w-]{43}$/.test(token)) return;
  try {
    const [body, signature] = token.split(".");
    if (!await crypto.subtle.verify("HMAC", key, fromBase64(signature), encoder.encode(body))) return;
    const payload = JSON.parse(decoder.decode(fromBase64(body)));
    if (payload.kind === kind && payload.exp > now) return payload;
  } catch {
    return;
  }
}
function json(body, status = 200, headers = {}) {
  return Response.json(body, { status, headers: { ...standardHeaders, ...headers } });
}
function callbackPage(ticket, cookie, frontend) {
  const contents = ticket
    ? '<p>Discord is linked. Return to Owlbear to finish creating your token. If Owlbear is still waiting, copy this code into the extension.</p><textarea readonly rows="3" aria-label="sign-in code" data-opener-origin="' + frontend + '">' + ticket +
      '</textarea><div class="actions"><button id="return" hidden>close this tab</button><button id="copy">copy sign-in code</button></div><p id="feedback" role="status"></p><script src="/callback.js" defer></script>'
    : '<p>Sign-in ended or expired. Return to Owlbear and try again.</p>';
  return new Response('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Discord Arrivals</title><link rel="stylesheet" href="/style.css"><h1>discord arrivals</h1>' + contents + '</html>', {
    headers: {
      ...standardHeaders, "Content-Type":"text/html; charset=utf-8",
      "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'",
      ...(cookie ? { "Set-Cookie": cookie } : {}),
    },
    status: ticket ? 200 : 400,
  });
}

function avatarUrl(user) {
  if (typeof user.avatar === "string" && /^(?:a_)?[0-9a-f]{32}$/.test(user.avatar)) {
    return "https://cdn.discordapp.com/avatars/" + user.id + "/" + user.avatar + ".png?size=256";
  }
  const i = /^[1-9]\d{3}$/.test(user.discriminator)
    ? Number(user.discriminator) % 5 : Number((BigInt(user.id) >> 22n) % 6n);
  return "https://cdn.discordapp.com/embed/avatars/" + i + ".png";
}

export function createWorker({ fetchDiscord = fetch, clock = Date.now } = {}) {
  return {
    async fetch(request, env) {
      const url = new URL(request.url);
      if (!url.pathname.startsWith("/oauth/")) return env.ASSETS.fetch(request);
      if (url.origin !== env.PUBLIC_ORIGIN || !snowflake(env.DISCORD_CLIENT_ID) ||
          !env.DISCORD_CLIENT_SECRET || (env.SIGNING_SECRET?.length ?? 0) < 32) {
        return json({ error: "Server configuration is incomplete." }, 503);
      }
      const key = await importKey(env.SIGNING_SECRET);
      const now = Math.floor(clock() / 1000);
      const redirect = env.PUBLIC_ORIGIN + "/oauth/callback";
      const frontend = new URL(env.FRONTEND_ORIGIN || env.PUBLIC_ORIGIN).origin;
      if (url.pathname === "/oauth/start" && request.method === "GET") {
        const [room, player, connection] = ["room", "player", "connection"].map((name) => url.searchParams.get(name));
        if (![room, player, connection].every(cleanId)) return json({error:"Missing Owlbear context."}, 400);
        const nonce = base64(crypto.getRandomValues(new Uint8Array(18)));
        const cookie = base64(crypto.getRandomValues(new Uint8Array(24)));
        const state = await seal(key, {kind:"state", room, player, connection, nonce, cookieHash:await digest(cookie), exp:now+STATE_SECONDS});
        const authorize = new URL("https://discord.com/oauth2/authorize");
        authorize.search = new URLSearchParams({
          client_id: env.DISCORD_CLIENT_ID, redirect_uri: redirect, response_type:"code", scope:"identify", state,
        });
        return new Response(null, {status:302, headers:{
          ...standardHeaders, Location:authorize.href,
          "Set-Cookie":"__Host-da-" + nonce + "=" + cookie + "; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=" + STATE_SECONDS,
        }});
      }
      if (url.pathname === "/oauth/callback" && request.method === "GET") {
        const state = await unseal(key, url.searchParams.get("state"), "state", now);
        if (!state) return callbackPage();
        const cookieName = "__Host-da-" + state.nonce;
        const cookie = request.headers.get("Cookie")?.split(/;\s*/)
          .find((part) => part.startsWith(cookieName + "="))?.slice(cookieName.length + 1);
        const code = url.searchParams.get("code");
        const expired = cookieName + "=; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0";
        if (!cookie || await digest(cookie) !== state.cookieHash) return callbackPage();
        if (!code || code.length > 512) return callbackPage(undefined, expired);
        try {
          const response = await fetchDiscord("https://discord.com/api/v10/oauth2/token", {
            method:"POST", redirect:"error", signal:AbortSignal.timeout(10000),
            body:new URLSearchParams({
              client_id:env.DISCORD_CLIENT_ID, client_secret:env.DISCORD_CLIENT_SECRET,
              grant_type:"authorization_code", code, redirect_uri:redirect,
            }),
          });
          if (!response.ok) return callbackPage(undefined, expired);
          const { access_token } = await response.json();
          if (typeof access_token !== "string" || !access_token) return callbackPage(undefined, expired);
          const who = await fetchDiscord("https://discord.com/api/v10/users/@me", {
            headers:{Authorization:"Bearer " + access_token}, redirect:"error", signal:AbortSignal.timeout(10000),
          });
          if (!who.ok) return callbackPage(undefined, expired);
          const user = await who.json();
          if (!snowflake(user.id)) return callbackPage(undefined, expired);
          const name = String(user.global_name || user.username || "Player").replace(/\s+/gu, " ").trim().slice(0, 48) || "Player";
          const profile = base64(new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode("profile:" + state.room + ":" + user.id))));
          const ticket = await seal(key, { kind:"claim", room:state.room, player:state.player, connection:state.connection,
            profile, name, avatar:avatarUrl(user), exp:now+TICKET_SECONDS });
          return callbackPage(ticket, expired, frontend);
        } catch {
          return callbackPage(undefined, expired);
        }
      }
      if (url.pathname === "/oauth/verify" && ["POST", "OPTIONS"].includes(request.method)) {
        const origin = request.headers.get("Origin");
        if (origin && origin !== frontend && origin !== url.origin) return json({error:"Invalid frontend origin."}, 403);
        const cors = origin ? {"Access-Control-Allow-Origin":origin, "Vary":"Origin"} : {};
        if (request.method === "OPTIONS") return new Response(null, {status:204, headers:{
          ...cors, "Access-Control-Allow-Methods":"POST", "Access-Control-Allow-Headers":"Content-Type",
        }});
        try {
          const raw = await request.text();
          if (raw.length > 6000) return json({error:"Invalid claim."}, 400, cors);
          const {ticket, room, player, connection} = JSON.parse(raw);
          const claim = await unseal(key, ticket, "claim", now);
          if (!claim || claim.room !== room || claim.player !== player || claim.connection !== connection)
            return json({error:"This sign-in code is expired or belongs to a different connection."}, 403, cors);
          return json({profile:claim.profile, name:claim.name, avatar:claim.avatar}, 200, cors);
        } catch {
          return json({error:"Invalid claim."}, 400, cors);
        }
      }
      return json({error:"Not found."}, 404);
    },
  };
}

export default createWorker();
