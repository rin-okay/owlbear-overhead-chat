import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";
import { readFileSync } from "node:fs";

const manifest = JSON.parse(readFileSync(resolve(__dirname, "public/manifest.json"), "utf8"));

export default defineConfig({
    base: "/owlbear-overhead-chat/motif/",
    plugins: [react()],
    define: { __MOTIF_VERSION__: JSON.stringify(manifest.version) },
    build: {
        rollupOptions: {
            input: {
                main: resolve(__dirname, "index.html"),
                background: resolve(__dirname, "background.html"),
            },
        },
    },
});
