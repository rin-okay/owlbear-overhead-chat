import OBR, { type Item, type Metadata } from "@owlbear-rodeo/sdk";
import { APP_KEY } from "./config";
import { constants } from "./constants";
import { AUDIO_TOKEN, RULE_PREFIX, TRIGGER_PREFIX, audioTokens, character, getAuto, triggerEvents,
    type AutoRule, type Listener, type Trigger } from "./auto/model";
import { validDrawing } from "./auto/geometry";
import { AUDIO_SETTINGS } from "./effects/audio";
import { LIBRARY_CHANGED, sendSpellsUpdate } from "./effects/localSpells";
import { publicAudioURL, validClip } from "./effects/messageListener";
import { getSpell, spellIDs } from "./effects/spells";
import { GLOBAL_STORAGE_KEYS } from "./components/Settings/settings";
import { sunoEmbedURL } from "./suno";
import type { Spell } from "./types/spells";

const TYPE = "motif-configuration";
const CAST_SETTING = APP_KEY + "/settings/" + GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS;
const library = constants.SPELL_LIST_METADATA_KEY;
const soundKey = (id: string) => APP_KEY + "/spells/" + id;
const isRecord = (value: unknown): value is Record<string, unknown> =>
    value !== null && typeof value === "object" && !Array.isArray(value);
const bit = (value: unknown) => typeof value === "boolean";
const id = (value: unknown) => typeof value === "string" && /^[\w-]{1,128}$/.test(value);
const name = (value: unknown) => typeof value === "string" && value.trim().length > 0 && value.length <= 255;
const volume = (value: unknown) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1;
function check(condition: unknown, message: string): asserts condition {
    if (!condition) throw Error(message);
}

export type Mix = { music: number; effect: number };
type SceneBackup = { triggers: Trigger[]; rules: AutoRule[]; listeners: Listener[]; playersCanCast: boolean };
type Backup = { type: typeof TYPE; version: 1; mix: Mix; sounds: Record<string, Spell>; scene: SceneBackup | null };

function libraryIds(): string[] {
    const value: unknown = JSON.parse(localStorage.getItem(library) ?? "[]");
    return Array.isArray(value) ? value.filter(id) : [];
}

export async function exportMotifConfiguration(mix: Mix) {
    check(await OBR.player.getRole() === "GM", "Only the GM can export a Motif configuration.");
    let scene: SceneBackup | null = null;
    if (await OBR.scene.isReady()) {
        const [metadata, items] = await Promise.all([OBR.scene.getMetadata(), OBR.scene.items.getItems(character)]);
        scene = { ...getAuto(metadata), playersCanCast: metadata[CAST_SETTING] === true,
            listeners: audioTokens(items).map(({ tokenId, userId, name }) => ({ tokenId, userId, name })) };
    }
    const sounds = Object.fromEntries(libraryIds().flatMap(key => {
        const cue = getSpell("$." + key, true);
        return cue ? [[key, cue]] : [];
    }));
    const backup: Backup = { type: TYPE, version: 1, mix, sounds, scene };
    const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "motif-configuration.json";
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 10000);
}

export function parseMotifConfiguration(value: unknown, existingSounds: string[]): Backup {
    check(isRecord(value) && value.type === TYPE && value.version === 1, "Choose a Motif configuration backup.");
    check(isRecord(value.mix) && volume(value.mix.music) && volume(value.mix.effect), "The backup has invalid mix levels.");
    check(isRecord(value.sounds) && Object.keys(value.sounds).length <= 50, "The backup has an invalid sound library.");
    const mix = value.mix as Mix;
    const sounds: Record<string, Spell> = {};
    for (const [key, raw] of Object.entries(value.sounds)) {
        check(/^[\w-]{1,80}$/.test(key) && !Object.hasOwn(Object.prototype, key) &&
            isRecord(raw) && name(raw.name) && isRecord(raw.audio), "A sound definition is invalid.");
        const a = raw.audio;
        check(typeof a.url === "string" && (a.category === "music" || a.category === "effect") &&
            typeof a.tags === "string" && a.tags.length <= 120 &&
            (a.folder === undefined || typeof a.folder === "string" && a.folder.length <= 80) &&
            (a.duration === undefined || Number.isFinite(a.duration) && Number(a.duration) > 0) &&
            validClip(a as unknown as Spell["audio"]), "Invalid sound settings for " + raw.name);
        const url = publicAudioURL(a.url);
        check(!sunoEmbedURL(url) || a.category === "music", "A Suno track must be in Music.");
        const { category, folder, duration, tags, volume, start, end, loop } = a as unknown as Spell["audio"];
        sounds[key] = { name: raw.name as string, audio: { url, category, folder, duration, tags, volume, start, end, loop } };
    }

    if (value.scene === null) return { type: TYPE, version: 1, mix, sounds, scene: null };
    const s = value.scene;
    check(isRecord(s) && bit(s.playersCanCast) && Array.isArray(s.triggers) && s.triggers.length <= 250 &&
        Array.isArray(s.rules) && s.rules.length <= 250 && Array.isArray(s.listeners) && s.listeners.length <= 1000,
        "The backup has invalid scene settings.");
    const triggers = new Map<string, Trigger>();
    for (const raw of s.triggers) {
        check(isRecord(raw) && id(raw.id) && name(raw.name) && (raw.kind === "line" || raw.kind === "region") &&
            Array.isArray(raw.points) && raw.points.length <= 64 &&
            raw.points.every(p => isRecord(p) && Number.isFinite(p.x) && Number.isFinite(p.y)) &&
            validDrawing(raw.kind, raw.points), "Invalid trigger geometry.");
        const { kind, points } = raw as Trigger;
        triggers.set(raw.id as string, { id: raw.id as string, name: raw.name as string, kind, points: points.map(({ x, y }) => ({ x, y })) });
    }
    check(triggers.size === s.triggers.length, "The backup has duplicate trigger IDs.");
    const rules = new Map<string, AutoRule>();
    const availableSounds = new Set([...spellIDs, ...existingSounds.concat(Object.keys(sounds)).map(key => "$." + key)]);
    for (const raw of s.rules) {
        check(isRecord(raw) && id(raw.id) && typeof raw.triggerId === "string" && typeof raw.soundId === "string" &&
            availableSounds.has(raw.soundId) && bit(raw.loop) && bit(raw.ripple) &&
            (raw.audience === "all" || raw.audience === "token") &&
            Array.isArray(raw.stopTags) && raw.stopTags.length <= 100 &&
            raw.stopTags.every(tag => typeof tag === "string" && tag.length <= 120), "An automation has invalid settings.");
        const trigger = triggers.get(raw.triggerId);
        check(trigger && ["none", ...triggerEvents(trigger.kind)].includes(String(raw.start)) &&
            ["none", ...triggerEvents(trigger.kind)].includes(String(raw.stop)), "An automation references a missing trigger or event.");
        const { id: ruleId, triggerId, soundId, start, stop, loop, audience, ripple, stopTags } = raw as AutoRule;
        rules.set(ruleId, { id: ruleId, triggerId, soundId, start, stop, loop, audience, ripple, stopTags });
    }
    check(rules.size === s.rules.length, "The backup has duplicate automation IDs.");
    const listeners = new Map<string, Listener>();
    for (const raw of s.listeners) {
        check(isRecord(raw) && id(raw.tokenId) && id(raw.userId) && name(raw.name), "A token listener is invalid.");
        const { tokenId, name: label, userId } = raw as Listener;
        listeners.set(tokenId, { tokenId, name: label, userId });
    }
    check(listeners.size === s.listeners.length, "The backup has duplicate token listeners.");
    return { type: TYPE, version: 1, mix, sounds, scene: {
        triggers: [...triggers.values()], rules: [...rules.values()], listeners: [...listeners.values()],
        playersCanCast: s.playersCanCast as boolean,
    } };
}

function matchListeners(listeners: Listener[], items: Item[]) {
    const match = new Map<string, string>();
    const foundById = new Map(items.map(item => [item.id, item]));
    for (const listener of listeners) {
        if (foundById.has(listener.tokenId)) match.set(listener.tokenId, listener.userId);
    }
    const nameCounts = new Map<string, number>();
    for (const { name } of listeners) nameCounts.set(name, (nameCounts.get(name) ?? 0) + 1);
    for (const listener of listeners) {
        if (foundById.has(listener.tokenId) || nameCounts.get(listener.name) !== 1) continue;
        const candidates = items.filter(item => item.name === listener.name);
        if (candidates.length === 1 && !match.has(candidates[0].id)) match.set(candidates[0].id, listener.userId);
    }
    return match;
}

export async function importMotifConfiguration(file: File) {
    check(file.size <= 2 * 1024 * 1024, "The backup file is larger than 2 MB.");
    let value: unknown;
    try { value = JSON.parse(await file.text()); } catch { throw Error("Choose a valid JSON backup."); }
    check(await OBR.player.getRole() === "GM", "Only the GM can import a Motif configuration.");
    const existingIds = libraryIds();
    const backup = parseMotifConfiguration(value, existingIds);
    const sounds = Object.entries(backup.sounds);
    const ids = [...new Set([...existingIds, ...sounds.map(([key]) => key)])];
    check(ids.length <= 50, "The combined library would exceed Motif’s 50 custom sounds.");
    let changedScene = false;
    const unsubscribe = OBR.scene.onReadyChange(() => { changedScene = true; });
    const originals = new Map<string, string | null>();
    const before: Metadata = {};
    let metadataApplied = false;
    function setLocal(key: string, value: unknown) {
        originals.set(key, localStorage.getItem(key));
        localStorage.setItem(key, JSON.stringify(value));
    }
    try {
        const ready = await OBR.scene.isReady();
        check(!backup.scene || ready, "Open a scene before importing this backup’s automations.");
        const update: Metadata = { [library]: ids };
        let matches = new Map<string, string>();
        if (backup.scene) {
            const { triggers, rules, listeners, playersCanCast } = backup.scene;
            for (const trigger of triggers) update[TRIGGER_PREFIX + trigger.id] = trigger;
            for (const rule of rules) update[RULE_PREFIX + rule.id] = rule;
            update[CAST_SETTING] = playersCanCast;
            matches = matchListeners(listeners, await OBR.scene.items.getItems(character));
        }
        if (ready) {
            const metadata = await OBR.scene.getMetadata();
            for (const key of Object.keys(update)) before[key] = metadata[key];
        }
        check(!changedScene && await OBR.player.getRole() === "GM", "The scene or your GM access changed.");
        for (const [key, cue] of sounds) setLocal(soundKey(key), cue);
        setLocal(library, ids);
        setLocal(AUDIO_SETTINGS, backup.mix);
        if (ready) {
            await OBR.scene.setMetadata(update);
            metadataApplied = true;
            check(!changedScene, "The scene changed during import.");
            if (matches.size) await OBR.scene.items.updateItems([...matches.keys()], items => {
                if (changedScene) throw Error("The scene changed during import.");
                for (const item of items) if (character(item)) item.metadata[AUDIO_TOKEN] = { userId: matches.get(item.id) };
            });
        }
        if (ready) sendSpellsUpdate("all");
        await Promise.allSettled([
            OBR.broadcast.sendMessage(LIBRARY_CHANGED, {}, { destination: "LOCAL" }),
            OBR.broadcast.sendMessage(AUDIO_SETTINGS, {}, { destination: "LOCAL" }),
        ]);
        return { mix: backup.mix, unmatched: (backup.scene?.listeners.length ?? 0) - matches.size };
    } catch (error) {
        if (metadataApplied && !changedScene) await OBR.scene.setMetadata(before).catch(console.warn);
        for (const [key, original] of originals) {
            try { if (original === null) localStorage.removeItem(key); else localStorage.setItem(key, original); } catch (cause) { console.warn(cause); }
        }
        throw error;
    } finally { unsubscribe(); }
}
