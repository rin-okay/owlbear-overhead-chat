import OBR from "@owlbear-rodeo/sdk";
import { setupAudioContextMenu } from "./auto/tools";
import { log_error } from "./logging";
import { setupEffectsTool } from "./effectsTool";
import { sendSpellsUpdate, setupGMLocalSpells, setupPlayerLocalSpells } from "./effects/localSpells";
import { constants } from "./constants";
import { setupMessageListener } from "./effects/messageListener";

function loadSpellListFromLocalStorage() {
    // Update scene metadata
    const spellListJSON = localStorage.getItem(constants.SPELL_LIST_METADATA_KEY);
    if (spellListJSON == undefined) {
        return;
    }
    const spellList = JSON.parse(spellListJSON);
    OBR.scene.setMetadata({[constants.SPELL_LIST_METADATA_KEY]: spellList});
}

function setupLocalSpells(role: "GM" | "PLAYER") {
    if (role === "PLAYER") {
        return setupPlayerLocalSpells();
    }
    else if (role === "GM") {
        return setupGMLocalSpells();
    }
    return null;
}

function setupScene() {
    let interval: number | undefined;
    let role: "GM" | "PLAYER" | undefined;
    let id: string | undefined;
    let disposed = false;
    let unsubscribeTool: (() => void) | undefined;
    let unsubscribeLocalSpells: (() => void) | null = null;

    function update(nextRole: "GM" | "PLAYER", nextId: string) {
        if (disposed || (nextRole === role && nextId === id)) return;
        role = nextRole;
        id = nextId;
        unsubscribeTool?.();
        unsubscribeLocalSpells?.();
        window.clearInterval(interval);
        if (role === "GM") {
            loadSpellListFromLocalStorage();
            interval = window.setInterval(() => sendSpellsUpdate("all"), 30000);
        }
        unsubscribeTool = setupEffectsTool(role, id);
        unsubscribeLocalSpells = setupLocalSpells(role);
    }

    const unsubscribePlayer = OBR.player.onChange(player => update(player.role, player.id));
    void Promise.all([OBR.player.getRole(), OBR.player.getId()]).then(([initialRole, initialId]) => {
        if (!role) update(initialRole, initialId);
    }).catch(log_error);

    return () => {
        disposed = true;
        window.clearInterval(interval);
        unsubscribePlayer();
        unsubscribeTool?.();
        unsubscribeLocalSpells?.();
    };
}

function setup() {
    setupMessageListener();
    void setupAudioContextMenu().catch(log_error);

    let unsubscribe: (() => void) | null = null;
    let sawSceneChange = false;
    void OBR.scene.isReady().then(ready => {
        if (!sawSceneChange && ready) unsubscribe = setupScene();
    }).catch(log_error);
    OBR.scene.onReadyChange(ready => {
        sawSceneChange = true;
        if (unsubscribe) {
            unsubscribe();
            unsubscribe = null;
        }
        if (ready) {
            unsubscribe = setupScene();
        }
    });
}

OBR.onReady(setup);
