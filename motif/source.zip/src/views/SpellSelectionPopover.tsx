import "./SpellSelectionPopover.css";

import { APP_KEY } from "../config";
import { LOCAL_STORAGE_KEYS, getSettingsValue } from "../components/Settings/settings";
import { getSpell, spellIDs } from "../effects/spells";
import { useEffect, useState } from "react";

import OBR from "@owlbear-rodeo/sdk";
import { setSelectedSpell, spellPopoverId, toolMetadataSelectedSpell } from "../effectsTool";
import { useOBR } from "../react-obr/providers";
import { LIBRARY_CHANGED } from "../effects/localSpells";
import { LIBRARY_FOLDERS, soundFolder, soundTags } from "../effects/libraryFolders";
import TrackDuration from "./TrackDuration";
import { constants } from "../constants";

export const mostRecentEffectsMetadataKey = `${APP_KEY}/most-recent-effects`;

async function selectSpell(spellName: string) {
    // Update recent spells list
    const mostRecentSpellsList = (await getMostRecentSpells()).filter(
        name => name != spellName
    );
    mostRecentSpellsList.splice(0, 0, spellName);
    if (mostRecentSpellsList.length > getSettingsValue(LOCAL_STORAGE_KEYS.MOST_RECENT_SPELLS_LIST_SIZE)) {
        mostRecentSpellsList.pop();
    }
    await OBR.player.setMetadata({ [mostRecentEffectsMetadataKey]: mostRecentSpellsList });

    await setSelectedSpell(spellName);

    // Close this popover
    await OBR.popover.close(spellPopoverId);
}

function checkForEscape(event: React.KeyboardEvent<HTMLDivElement>) {
    if (event.code === "Escape") {
        OBR.popover.close(spellPopoverId);
    }
}

async function getMostRecentSpells() {
    const metadata = await OBR.player.getMetadata();
    if (metadata == undefined) {
        return [];
    }
    const mostRecentSpellsList = metadata[mostRecentEffectsMetadataKey];
    if (!Array.isArray(mostRecentSpellsList) || mostRecentSpellsList.length == 0) {
        return [];
    }
    return mostRecentSpellsList as string[];
}

async function getSortedSpellsList() {
    const [metadata, mostRecentSpellsList] = await Promise.all([
        OBR.scene.getMetadata(),
        getMostRecentSpells()
    ]);
    const localSpellIDs = Array.isArray(metadata[constants.SPELL_LIST_METADATA_KEY]) ? metadata[constants.SPELL_LIST_METADATA_KEY] as string[] : [];
    const allSpellIDs = [...spellIDs, ...localSpellIDs.map(id => `$.${id}`)].sort((s1, s2) => s1.localeCompare(s2));
    const effectNamesWithoutMostRecent = allSpellIDs.filter(name => !mostRecentSpellsList.includes(name));
    return mostRecentSpellsList.filter(id => allSpellIDs.includes(id)).concat(effectNamesWithoutMostRecent);
}

function normalizeSearch(str: string) {
    return str.toLowerCase().replaceAll("_", " ").replaceAll(".", " ");
}

export function EffectsList({ searchString, sortedSpellsList, isGM, choose, selectedId }: {
    searchString: string; sortedSpellsList: string[]; isGM: boolean; choose: (id: string) => void; selectedId?: string;
}) {
    const query = normalizeSearch(searchString.trim());
    const terms = query ? query.split(/\s+/) : [];
    const library = sortedSpellsList.flatMap(id => {
        const spell = getSpell(id, isGM);
        if (!spell) return [];
        return [{ id, spell, folder: soundFolder(spell.audio), tags: soundTags(spell.audio.tags) }];
    });
    const categories = (["effect", "music"] as const).map(category => {
        const group = LIBRARY_FOLDERS[category];
        const folders = group.folders.map(folder => ({
            ...folder,
            tracks: library.filter(({ id, spell, folder: path }) =>
                spell.audio.category === category && path === folder.id &&
                terms.every(term => normalizeSearch([id, spell.name, spell.audio.tags, group.label, folder.label].join(" ")).includes(term))),
        }));
        return { category, label: group.label, folders };
    });
    const hasResults = categories.some(group => group.folders.some(folder => folder.tracks.length));
    if (query && !hasResults) return <p role="status">No matching sounds.</p>;

    return <div className="folder-tree" key={query ? "search" : "browse"}>
        {categories.map(group => (query && !group.folders.some(folder => folder.tracks.length)) ? null :
            <details key={group.category} className="library-category" open>
                <summary>{group.label}</summary>
                {group.folders.map(folder => (query && !folder.tracks.length) ? null :
                    <details key={folder.id} className="library-folder" open={query ? true : folder.tracks.length > 0}>
                        <summary>{folder.label}</summary>
                        {folder.tracks.length ? <ul className="results-list">
                            {folder.tracks.map(({ id, spell, tags }) => <li key={id}>
                                <button type="button" className="cue-choice" aria-pressed={id === selectedId} onClick={() => choose(id)}>
                                    <span className="cue-title">
                                        <span className="cue-name">{spell.name}</span>
                                        {tags.map(tag => <span key={tag} className="cue-tag">{tag}</span>)}
                                    </span>
                                    <TrackDuration audio={spell.audio}/>
                                </button>
                            </li>)}
                        </ul> : <p className="empty-folder">No sounds yet.</p>}
                    </details>)}
            </details>)}
    </div>;
}

export function LibrarySearch({ value, onChange, autoFocus }: {
    value: string; onChange: (value: string) => void; autoFocus?: boolean;
}) {
    return <input type="search" className="search-input library-search" aria-label="Search"
        placeholder="search" autoFocus={autoFocus} value={value} onChange={event => onChange(event.target.value)}/>;
}

export function useSpellList() {
    const obr = useOBR();
    const [ids, setIds] = useState<string[]>(spellIDs);
    useEffect(() => {
        if (!obr.ready) return;
        let active = true;
        const reload = () => {
            if (!obr.sceneReady) { setIds(spellIDs); return; }
            void getSortedSpellsList().then(ids => { if (active) setIds(ids); }).catch(console.warn);
        };
        reload();
        const unsubscribeMetadata = OBR.scene.onMetadataChange(reload);
        const unsubscribeLibrary = OBR.broadcast.onMessage(LIBRARY_CHANGED, reload);
        return () => { active = false; unsubscribeMetadata(); unsubscribeLibrary(); };
    }, [obr.ready, obr.sceneReady]);
    return ids;
}

export default function SpellSelectionPopover() {
    const obr = useOBR();
    const [search, setSearch] = useState("");
    const sortedSpellsList = useSpellList();
    if (!obr.ready) return null;
    return <div className="popover-container">
        <div className="spell-popover" onKeyDown={checkForEscape}>
            <div className="search-container">
                <LibrarySearch value={search} onChange={setSearch} autoFocus/>
                <div className="library-results">
                    <EffectsList sortedSpellsList={sortedSpellsList} searchString={search} isGM={obr.player?.role === "GM"} selectedId={obr.player?.metadata[toolMetadataSelectedSpell] as string | undefined} choose={id => void selectSpell(id).catch(console.warn)} />
                </div>
            </div>
        </div>
    </div>;
}
