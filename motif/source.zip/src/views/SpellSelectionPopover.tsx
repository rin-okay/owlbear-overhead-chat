import "./SpellSelectionPopover.css";

import { APP_KEY } from "../config";
import { LOCAL_STORAGE_KEYS, getSettingsValue } from "../components/Settings/settings";
import { getSpell, spellIDs } from "../effects/spells";
import { useEffect, useState } from "react";

import OBR from "@owlbear-rodeo/sdk";
import { setSelectedSpell, spellPopoverId } from "../effectsTool";
import { useOBR } from "../react-obr/providers";
import { LIBRARY_CHANGED } from "../effects/localSpells";
import { constants } from "../constants";

export const mostRecentEffectsMetadataKey = `${APP_KEY}/most-recent-effects`;

async function selectSpell(spellName: string) {
    // Update recent spells list
    const mostRecentSpellsList = (await getMostRecentSpells()).filter(
        name => name != spellName
    );
    mostRecentSpellsList.splice(0, 0, spellName);
    if (mostRecentSpellsList.length > getSettingsValue(LOCAL_STORAGE_KEYS.MOST_RECENT_SPELLS_LIST_SIZE)) {
        mostRecentSpellsList.pop();
    }
    await OBR.player.setMetadata({ [mostRecentEffectsMetadataKey]: mostRecentSpellsList });

    await setSelectedSpell(spellName);

    // Close this popover
    await OBR.popover.close(spellPopoverId);
}

function checkForEscape(event: React.KeyboardEvent<HTMLDivElement>) {
    if (event.code === "Escape") {
        OBR.popover.close(spellPopoverId);
    }
}

async function getMostRecentSpells() {
    const metadata = await OBR.player.getMetadata();
    if (metadata == undefined) {
        return [];
    }
    const mostRecentSpellsList = metadata[mostRecentEffectsMetadataKey];
    if (!Array.isArray(mostRecentSpellsList) || mostRecentSpellsList.length == 0) {
        return [];
    }
    return mostRecentSpellsList as string[];
}

async function getSortedSpellsList() {
    const [metadata, mostRecentSpellsList] = await Promise.all([
        OBR.scene.getMetadata(),
        getMostRecentSpells()
    ]);
    const localSpellIDs = Array.isArray(metadata[constants.SPELL_LIST_METADATA_KEY]) ? metadata[constants.SPELL_LIST_METADATA_KEY] as string[] : [];
    const allSpellIDs = [...spellIDs, ...localSpellIDs.map(id => `$.${id}`)].sort((s1, s2) => s1.localeCompare(s2));
    const effectNamesWithoutMostRecent = allSpellIDs.filter(name => !mostRecentSpellsList.includes(name));
    return mostRecentSpellsList.filter(id => allSpellIDs.includes(id)).concat(effectNamesWithoutMostRecent);
}

function normalizeSearch(str: string) {
    return str.toLowerCase().replaceAll("_", " ").replaceAll(".", " ");
}

export function EffectsList({ searchString, sortedSpellsList, isGM, choose }: {
    searchString: string; sortedSpellsList: string[]; isGM: boolean; choose: (id: string) => void;
}) {
    const query = normalizeSearch(searchString.trim());
    return <ul className="results-list">
        {sortedSpellsList.flatMap(id => {
            const spell = getSpell(id, isGM);
            if (!spell || !normalizeSearch([id, spell.name, spell.audio.tags, spell.audio.category].join(" ")).includes(query)) return [];
            return [<li key={id}><button className="cue-choice" onClick={() => choose(id)}>
                <span className="cue-type">{spell.audio.category === "music" ? "Music" : "SFX"}</span>
                <span>{spell.name}</span>{isGM && <small>{id}</small>}
            </button></li>];
        })}
    </ul>;
}

export function useSpellList() {
    const obr = useOBR();
    const [ids, setIds] = useState<string[]>(spellIDs);
    useEffect(() => {
        if (!obr.ready) return;
        let active = true;
        const reload = () => {
            if (!obr.sceneReady) { setIds(spellIDs); return; }
            void getSortedSpellsList().then(ids => { if (active) setIds(ids); }).catch(console.warn);
        };
        reload();
        const unsubscribeMetadata = OBR.scene.onMetadataChange(reload);
        const unsubscribeLibrary = OBR.broadcast.onMessage(LIBRARY_CHANGED, reload);
        return () => { active = false; unsubscribeMetadata(); unsubscribeLibrary(); };
    }, [obr.ready, obr.sceneReady]);
    return ids;
}

export default function SpellSelectionPopover() {
    const obr = useOBR();
    const [search, setSearch] = useState("");
    const sortedSpellsList = useSpellList();
    if (!obr.ready) return null;
    return <div className="popover-container">
        <div className="spell-popover" onKeyDown={checkForEscape}>
            <div className="search-container">
                <input type="search" className="search-input" aria-label="Search sounds" placeholder="Find a sound…" autoFocus value={search} onChange={event => setSearch(event.target.value)} />
                <EffectsList sortedSpellsList={sortedSpellsList} searchString={search} isGM={obr.player?.role === "GM"} choose={id => void selectSpell(id).catch(console.warn)} />
            </div>
        </div>
        <div className="filler" onClick={() => void OBR.popover.close(spellPopoverId)} />
    </div>;
}
