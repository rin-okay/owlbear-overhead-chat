import OBR from "@owlbear-rodeo/sdk";
import { useState } from "react";
import { TRIGGER_PREFIX, getAuto, type Trigger } from "../auto/model";
import { validDrawing } from "../auto/geometry";
import { NAME_TRIGGER } from "../auto/tools";
import { useOBR } from "../react-obr/providers";

function getDraft() {
    try {
        const draft = JSON.parse(decodeURIComponent(window.location.hash.slice(1))) as Pick<Trigger, "kind" | "points">;
        if ((draft.kind === "line" || draft.kind === "region") && validDrawing(draft.kind, draft.points)) return draft;
    } catch { /* the dialog can be opened without a draft */ }
}

export default function NameTrigger() {
    const obr = useOBR();
    const [draft] = useState(getDraft);
    const [name, setName] = useState("");
    const [error, setError] = useState("");
    const [saving, setSaving] = useState(false);
    return <main className="motif-panel panel-content">
        <h1>{draft?.kind === "region" ? "Name region" : "Name trigger"}</h1>
        <form className="audio-form" onSubmit={async event => {
            event.preventDefault();
            if (!draft || saving || !name.trim() || obr.player?.role !== "GM" || !obr.sceneReady) return;
            setSaving(true);
            setError("");
            try {
                const title = name.trim();
                const config = getAuto(await OBR.scene.getMetadata());
                if (config.triggers.some(trigger => trigger.name.toLowerCase() === title.toLowerCase())) {
                    setError("A trigger with that name already exists.");
                    return;
                }
                const id = crypto.randomUUID();
                await OBR.scene.setMetadata({ [TRIGGER_PREFIX + id]: { ...draft, id, name: title } satisfies Trigger });
                await OBR.modal.close(NAME_TRIGGER);
            } catch { setError("Couldn’t save this trigger."); }
            finally { setSaving(false); }
        }}>
            <input aria-label="Name" placeholder="Name" autoFocus maxLength={80} required value={name} onChange={event => setName(event.target.value)}/>
            <div className="inline-buttons">
                <button type="submit" disabled={!draft || !name.trim() || !obr.sceneReady || obr.player?.role !== "GM" || saving}>Save</button>
                <button type="button" onClick={() => void OBR.modal.close(NAME_TRIGGER)}>Cancel</button>
            </div>
            {error && <small role="alert">{error}</small>}
        </form>
    </main>;
}
