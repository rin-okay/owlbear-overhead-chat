import OBR from "@owlbear-rodeo/sdk";
import { ACTIVE_EFFECTS } from "../effects/audio";
import { useOBR } from "../react-obr/providers";
import { SUNO_POPOVER, sunoEmbedURL } from "../suno";
import type { ActiveEffect } from "../types/messageListener";

export default function SunoPlayer() {
    const obr = useOBR();
    const entries = (obr.roomMetadata[ACTIVE_EFFECTS] as ActiveEffect[] | undefined) ?? [];
    const cue = entries.find(entry => entry.visible && entry.at !== null && entry.category === "music" && sunoEmbedURL(entry.url));
    const src = cue && sunoEmbedURL(cue.url);
    return <main className="motif-panel panel-content suno-player">
        <div>
            <h1>{cue?.name ?? "Suno player"}</h1>
            <button type="button" onClick={() => void OBR.popover.close(SUNO_POPOVER)}>Close</button>
        </div>
        {!obr.ready ? <p>Connecting to the room…</p> : src ?
            <iframe key={cue.id} src={src} title={cue.name + " on Suno"} allow="autoplay" /> :
            <p>No Suno track is shared in this room.</p>}
    </main>;
}
