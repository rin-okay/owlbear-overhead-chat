import OBR from "@owlbear-rodeo/sdk";
import { useCallback, useEffect, useRef, useState } from "react";
import { ACTIVE_EFFECTS } from "../effects/audio";
import { useOBR } from "../react-obr/providers";
import { resizeSunoPlayer, SUNO_EXPAND, SUNO_POPOVER, sunoEmbedURL } from "../suno";
import type { ActiveEffect } from "../types/messageListener";

export default function SunoPlayer() {
    const obr = useOBR();
    const entries = (obr.roomMetadata[ACTIVE_EFFECTS] as ActiveEffect[] | undefined) ?? [];
    const cue = entries.find(entry => entry.visible && entry.at !== null && entry.category === "music" && sunoEmbedURL(entry.url));
    const src = cue && sunoEmbedURL(cue.url);
    const [minimized, setMinimized] = useState(false);
    const resizing = useRef(false);
    const changeSize = useCallback(async (collapse: boolean) => {
        if (resizing.current || collapse === minimized) return;
        resizing.current = true;
        try {
            await resizeSunoPlayer(collapse);
            setMinimized(collapse);
        } catch (error) {
            console.warn(error);
            await resizeSunoPlayer(minimized).catch(console.warn);
            void OBR.notification.show("Couldn’t resize the Suno player.");
        } finally {
            resizing.current = false;
        }
    }, [minimized]);
    useEffect(() => {
        if (!obr.ready) return;
        return OBR.broadcast.onMessage(SUNO_EXPAND, () => void changeSize(false));
    }, [obr.ready, changeSize]);

    return <main className={`motif-panel panel-content suno-player${minimized ? " suno-minimized" : ""}`}>
        <div>
            <h1 title={cue?.name}>{cue?.name ?? "Suno player"}</h1>
            <button type="button" aria-expanded={!minimized} onClick={() => void changeSize(!minimized)}>
                {minimized ? "Expand" : "Minimize"}
            </button>
            {!minimized && <button type="button" onClick={() => void OBR.popover.close(SUNO_POPOVER)}>Close</button>}
        </div>
        {src ? <iframe key={cue.id} src={src} title={cue.name + " on Suno"} allow="autoplay"
            aria-hidden={minimized} tabIndex={minimized ? -1 : undefined}/> :
            !minimized && <p>{obr.ready ? "No Suno track is shared in this room." : "Connecting to the room…"}</p>}
    </main>;
}
