import "./Main.css";

import { Box, Tab, Tabs } from "@mui/material";
import { FaBook, FaDisplay, FaGear, FaPlus, FaWaveSquare } from "react-icons/fa6";
import OBR from "@owlbear-rodeo/sdk";
import { useState } from "react";
import CustomSpells from "../components/CustomSpells";
import SceneControls from "../components/SceneControls";
import { useOBR } from "../react-obr/providers";
import { doSpell, getSpell } from "../effects/spells";
import { setSelectedSpell, toolMetadataSelectedSpell } from "../effectsTool";
import { EffectsList, useSpellList } from "./SpellSelectionPopover";
import { AUDIO_SETTINGS } from "../effects/audio";
import { GLOBAL_STORAGE_KEYS, setGlobalSettingsValue } from "../components/Settings/settings";
import { APP_KEY } from "../config";
import { sunoEmbedURL } from "../suno";

function SpellBook() {
    const obr = useOBR();
    const gm = obr.player?.role === "GM";
    const ids = useSpellList();
    const [query, setQuery] = useState("");
    const [local, pick] = useState<string>();
    const id = local ?? obr.player?.metadata[toolMetadataSelectedSpell] as string | undefined;
    const selected = id ? getSpell(id, gm) : undefined;
    return <section>
        <label className="search-label">Find a sound <input type="search" value={query} onChange={event => setQuery(event.target.value)}/></label>
        <EffectsList sortedSpellsList={ids} searchString={query} isGM={gm} choose={id => {
            pick(id);
            void setSelectedSpell(id).catch(console.warn);
        }}/>
        <button disabled={!selected || !obr.player} type="button" onClick={() => {
            if (id && obr.player) void doSpell(id, obr.player.id, gm).catch(console.warn);
        }}>{selected && sunoEmbedURL(selected.audio.url) ? "Share Suno track" : "Play selected sound"}{selected ? " · " + selected.name : ""}</button>
    </section>;
}

function Settings() {
    const obr = useOBR();
    const [mix, changeMix] = useState<{music: number; effect: number}>(() => ({
        music: .7, effect: .85, ...JSON.parse(localStorage.getItem(AUDIO_SETTINGS) ?? "{}"),
    }));
    const gm = obr.player?.role === "GM";
    return <section className="audio-form">
        <h2>Your mix</h2>
        {(["music", "effect"] as const).map(key => <label key={key}>{key === "music" ? "Music" : "Effects"}
            <input type="range" min="0" max="1" step=".01" value={mix[key]} onChange={event => {
                const next = { ...mix, [key]: Number(event.target.value) };
                localStorage.setItem(AUDIO_SETTINGS, JSON.stringify(next));
                changeMix(next);
                void OBR.broadcast.sendMessage(AUDIO_SETTINGS, {}, { destination: "LOCAL" });
            }}/>
        </label>)}
        {gm && obr.sceneReady && <label className="check"><input type="checkbox"
            checked={obr.sceneMetadata[`${APP_KEY}/settings/${GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS}`] === true}
            onChange={event => void setGlobalSettingsValue(GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS, event.target.checked)}/>
            Players can play sounds in this scene
        </label>}
    </section>;
}

const MENU_OPTIONS = [
    { label: "Library", icon: <FaBook/>, component: <SpellBook/>, role: "PLAYER" },
    { label: "Custom", icon: <FaPlus/>, component: <CustomSpells/>, role: "GM" },
    { label: "Active", icon: <FaDisplay/>, component: <SceneControls/>, role: "PLAYER" },
    { label: "Settings", icon: <FaGear/>, component: <Settings/>, role: "PLAYER" },
];

export default function Main() {
    const obr = useOBR();
    const [selectedTab, setSelectedTab] = useState(0);
    const gm = obr.player?.role === "GM";
    const index = !gm && selectedTab === 1 ? 0 : selectedTab;
    return <Box className="motif-panel">
        <header><FaWaveSquare/><h1>Motif</h1></header>
        <Tabs value={index} onChange={(_, value) => setSelectedTab(value)} aria-label="Motif">
            {MENU_OPTIONS.map((option, i) => option.role === "GM" && !gm ? null : <Tab key={option.label}
                value={i} label={option.label} icon={option.icon} iconPosition="start" sx={{ minWidth: 0, px: 1.4 }}/>)}
        </Tabs>
        <Box className="panel-content">{MENU_OPTIONS[index].component}</Box>
    </Box>;
}
