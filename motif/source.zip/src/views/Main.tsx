import { Box, Tab, Tabs } from "@mui/material";
import { FaBook, FaDisplay, FaGear, FaPlus, FaBolt } from "react-icons/fa6";
import OBR from "@owlbear-rodeo/sdk";
import { useState } from "react";
import CustomSpells from "../components/CustomSpells";
import AutoControls from "../components/AutoControls";
import SceneControls from "../components/SceneControls";
import { useOBR } from "../react-obr/providers";
import { doSpell, getSpell } from "../effects/spells";
import { setSelectedSpell, toolMetadataSelectedSpell } from "../effectsTool";
import { EffectsList, LibrarySearch, useSpellList } from "./SpellSelectionPopover";
import { AUDIO_SETTINGS } from "../effects/audio";
import { GLOBAL_STORAGE_KEYS, setGlobalSettingsValue } from "../components/Settings/settings";
import { APP_KEY } from "../config";
import { sunoEmbedURL } from "../suno";

function SpellBook({ ids, selected, choose }: { ids: string[]; selected?: string; choose: (id: string) => void }) {
    const obr = useOBR();
    const [query, setQuery] = useState("");
    return <section className="sound-library">
        <LibrarySearch value={query} onChange={setQuery}/>
        <div className="library-results">
            <EffectsList sortedSpellsList={ids} searchString={query} isGM={obr.player?.role === "GM"}
                selectedId={selected} choose={choose}/>
        </div>
    </section>;
}

function Settings() {
    const obr = useOBR();
    const [mix, changeMix] = useState<{music: number; effect: number}>(() => ({
        music: .7, effect: .85, ...JSON.parse(localStorage.getItem(AUDIO_SETTINGS) ?? "{}"),
    }));
    const gm = obr.player?.role === "GM";
    return <section className="settings-panel">
        <div className="audio-form">
            <h2>Your mix</h2>
            {(["music", "effect"] as const).map(key => <label key={key}>{key === "music" ? "Music" : "Effects"}
                <input type="range" min="0" max="1" step=".01" value={mix[key]} onChange={event => {
                    const next = { ...mix, [key]: Number(event.target.value) };
                    localStorage.setItem(AUDIO_SETTINGS, JSON.stringify(next));
                    changeMix(next);
                    void OBR.broadcast.sendMessage(AUDIO_SETTINGS, {}, { destination: "LOCAL" });
                }}/>
            </label>)}
            {gm && obr.sceneReady && <label className="check"><input type="checkbox"
                checked={obr.sceneMetadata[`${APP_KEY}/settings/${GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS}`] === true}
                onChange={event => void setGlobalSettingsValue(GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS, event.target.checked)}/>
                Players can play sounds in this scene
            </label>}
        </div>
        <small className="settings-version">v{__MOTIF_VERSION__}</small>
    </section>;
}

const MENU_OPTIONS = [
    { label: "Library", icon: <FaBook/>, component: null, role: "PLAYER" },
    { label: "Custom", icon: <FaPlus/>, component: <CustomSpells/>, role: "GM" },
    { label: "Active", icon: <FaDisplay/>, component: <SceneControls/>, role: "PLAYER" },
    { label: "Auto", icon: <FaBolt/>, component: null, role: "GM" },
    { label: "Settings", icon: <FaGear/>, component: <Settings/>, role: "PLAYER" },
];

export default function Main() {
    const obr = useOBR();
    const [selectedTab, setSelectedTab] = useState(0);
    const libraryIds = useSpellList();
    const gm = obr.player?.role === "GM";
    const index = !gm && MENU_OPTIONS[selectedTab].role === "GM" ? 0 : selectedTab;
    const selectedId = obr.player?.metadata[toolMetadataSelectedSpell] as string | undefined;
    const selected = selectedId ? getSpell(selectedId, gm) : undefined;
    return <Box className="motif-panel motif-browser">
        <Tabs className="motif-tabs" sx={{ minHeight: 36 }} TabIndicatorProps={{ sx: { display: "none" } }} variant="fullWidth" value={index} onChange={(_, value) => setSelectedTab(value)} aria-label="Motif">
            {MENU_OPTIONS.map((option, i) => option.role === "GM" && !gm ? null : <Tab key={option.label}
                value={i} label={option.label} icon={option.icon} iconPosition="start" sx={{ minWidth: 0, minHeight: 36, height: 36, py: 0, px: .5, "& .MuiTab-iconWrapper": { marginRight: .5 } }}/>)}
        </Tabs>
        <Box className={index === 0 ? "panel-content library-content" : "panel-content"}>
            {index === 0 ? <SpellBook ids={libraryIds} selected={selectedId} choose={id => void setSelectedSpell(id).catch(console.warn)}/> :
                MENU_OPTIONS[index].label === "Auto" ? <AutoControls ids={libraryIds}/> : MENU_OPTIONS[index].component}
        </Box>
        <footer className="playback-footer">
            <span>{selected?.name ?? "No sound selected"}</span>
            <button type="button" disabled={!selected || !obr.player} onClick={() => {
                if (selectedId && obr.player) void doSpell(selectedId, obr.player.id, gm).catch(console.warn);
            }}>{selected && sunoEmbedURL(selected.audio.url) ? "Share Suno track" : "Play selected sound"}</button>
        </footer>
    </Box>;
}
