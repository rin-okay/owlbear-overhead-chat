import { useEffect, useRef, useState } from "react";
import type { Sound } from "../types/spells";
import { formatDuration } from "../effects/libraryFolders";
import { sunoEmbedURL } from "../suno";

const durations = new Map<string, Promise<number | undefined>>();

function readDuration(url: string) {
    const active = durations.get(url);
    if (active) return active;
    const request = new Promise<number | undefined>(resolve => {
        const audio = new Audio();
        const finish = (duration?: number) => {
            window.clearTimeout(timer);
            audio.onloadedmetadata = audio.onerror = null;
            audio.removeAttribute("src");
            audio.load();
            resolve(duration);
        };
        const timer = window.setTimeout(() => finish(), 8000);
        audio.preload = "metadata";
        audio.onloadedmetadata = () => finish(Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : undefined);
        audio.onerror = () => finish();
        audio.src = url;
    });
    durations.set(url, request);
    return request;
}

export default function TrackDuration({ audio }: { audio: Sound }) {
    const ref = useRef<HTMLSpanElement>(null);
    const [found, setFound] = useState<{url: string; duration?: number}>();
    const given = Number.isFinite(audio.duration) && audio.duration! > 0 ? audio.duration : undefined;
    const { url } = audio;

    useEffect(() => {
        if (given !== undefined || sunoEmbedURL(url) || !ref.current) return;
        let active = true;
        const observe = () => void readDuration(url).then(duration => {
            if (active) setFound({ url, duration });
        });
        const observer = new IntersectionObserver(entries => {
            if (!entries.some(entry => entry.isIntersecting)) return;
            observer.disconnect();
            observe();
        });
        observer.observe(ref.current);
        return () => { active = false; observer.disconnect(); };
    }, [given, url]);

    const duration = given ?? (found?.url === audio.url ? found.duration : undefined);
    return <span ref={ref} className="cue-duration" aria-label={duration === undefined ? "Duration unavailable" : "Duration " + formatDuration(duration)}>
        {duration === undefined ? "—" : formatDuration(duration)}
    </span>;
}
