import OBR from "@owlbear-rodeo/sdk";
import { useMemo, useState } from "react";
import { AUDIO_TOKEN, PLAY_RULE, RULE_PREFIX, TRIGGER_PREFIX, getAuto, triggerEvents } from "../auto/model";
import { useAudioTokens } from "../auto/hooks";
import type { AudioToken, AutoRule, Trigger, TriggerEvent } from "../auto/model";
import { getSpell } from "../effects/spells";
import { soundTags } from "../effects/libraryFolders";
import { useOBR } from "../react-obr/providers";
import { sunoEmbedURL } from "../suno";

const eventLabels: Record<TriggerEvent | "none", string> = { none: "None", enter: "Enter", exit: "Exit", cross: "Cross" };

type Cue = { id: string; name: string; category: "music" | "effect"; loop: boolean; tags: string[] };

function RuleForm({ initial, triggers, cues, tags, saving, save, cancel }: {
    initial: AutoRule; triggers: Trigger[]; cues: Cue[]; tags: string[];
    saving: boolean; save: (rule: AutoRule) => void; cancel: () => void;
}) {
    const [rule, setRule] = useState(initial);
    const trigger = triggers.find(item => item.id === rule.triggerId);
    const cue = cues.find(item => item.id === rule.soundId);
    const events = trigger ? triggerEvents(trigger.kind) : [];
    const update = (patch: Partial<AutoRule>) => setRule(old => ({ ...old, ...patch }));
    return <form className="audio-form auto-card" onSubmit={event => {
        event.preventDefault();
        if (trigger && cue) save(rule);
    }}>
        <label>Trigger
            <select value={rule.triggerId} required onChange={event => {
                const next = triggers.find(item => item.id === event.target.value);
                const kind = next?.kind;
                const allowed = next ? triggerEvents(next.kind) : [];
                update({ triggerId: event.target.value,
                    start: rule.start === "none" || allowed.includes(rule.start) ? rule.start : kind === "line" ? "cross" : "enter",
                    stop: rule.stop === "none" || allowed.includes(rule.stop) ? rule.stop : "none" });
            }}>
                <option value="">Choose a trigger</option>
                {triggers.map(item => <option key={item.id} value={item.id}>{item.name} ({item.kind})</option>)}
            </select>
        </label>
        <label>Sound or music
            <select value={rule.soundId} required onChange={event => {
                const selected = cues.find(item => item.id === event.target.value);
                update({ soundId: event.target.value, loop: selected?.loop ?? false });
            }}>
                <option value="">Choose a cue</option>
                {(["effect", "music"] as const).map(category => <optgroup key={category} label={category === "music" ? "Music" : "Sound effects"}>
                    {cues.filter(item => item.category === category).map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                </optgroup>)}
            </select>
        </label>
        <div className="auto-pair">
            {(["start", "stop"] as const).map(field => <label key={field}>{field === "start" ? "Start on" : "Stop on"}
                <select value={rule[field]} onChange={event => update({ [field]: event.target.value as AutoRule[typeof field] })}>
                    {(["none", ...events] as const).map(value => <option key={value} value={value}>{eventLabels[value]}</option>)}
                </select>
            </label>)}
        </div>
        <label>Play for
            <select value={rule.audience} onChange={event => update({ audience: event.target.value as AutoRule["audience"] })}>
                <option value="all">All audio-enabled tokens</option>
                <option value="token">Triggering token</option>
            </select>
        </label>
        <label className="check"><input type="checkbox" checked={rule.loop} onChange={event => update({ loop: event.target.checked })}/> Loop</label>
        <label className="check"><input type="checkbox" checked={rule.ripple} onChange={event => update({ ripple: event.target.checked })}/> Play ripple at trigger</label>
        <fieldset className="auto-tags">
            <legend>Disable existing music with these tags</legend>
            {[...new Set([...tags, ...rule.stopTags])].sort().map(tag => <label key={tag} className="check">
                <input type="checkbox" checked={rule.stopTags.includes(tag)} onChange={event => update({ stopTags: event.target.checked
                    ? [...rule.stopTags, tag] : rule.stopTags.filter(item => item !== tag) })}/>{tag}
            </label>)}
        </fieldset>
        <div className="inline-buttons">
            <button type="submit" disabled={!trigger || !cue || saving}>Save rule</button>
            <button type="button" onClick={cancel} disabled={saving}>Cancel</button>
        </div>
    </form>;
}

function RuleRow({ rule, trigger, cue, tokens, edit, remove, play }: {
    rule: AutoRule; trigger: Trigger; cue?: Cue; tokens: AudioToken[];
    edit: () => void; remove: () => void; play: (tokenId?: string) => void;
}) {
    const [tokenId, setTokenId] = useState("");
    return <li className="auto-card">
        <div className="auto-heading">
            <div>
                <p>{trigger.name} · {cue?.name ?? "Unavailable cue"}</p>
                <small>{eventLabels[rule.start]} to start · {eventLabels[rule.stop]} to stop · {rule.loop ? "Loop" : "Play once"} · {rule.audience === "all" ? "All" : "Triggering token"}</small>
            </div>
            <div className="inline-buttons"><button type="button" onClick={edit}>Edit</button>
                <button type="button" aria-label={`Remove rule for ${trigger.name}`} onClick={remove}>Remove</button></div>
        </div>
        {rule.start === "none" && <div className="audio-form auto-pair">
            {rule.audience === "token" && <select aria-label="Token for manual start" value={tokenId} onChange={event => setTokenId(event.target.value)}>
                <option value="">Choose a token</option>
                {tokens.map(token => <option key={token.tokenId} value={token.tokenId}>{token.name}</option>)}
            </select>}
            <button type="button" disabled={!cue || (rule.audience === "token" ? !tokens.some(token => token.tokenId === tokenId) : !tokens.length)}
                onClick={() => play(tokenId || undefined)}>Play rule</button>
        </div>}
    </li>;
}

export default function AutoControls({ ids }: { ids: string[] }) {
    const obr = useOBR();
    const tokens = useAudioTokens(obr.sceneReady);
    const config = getAuto(obr.sceneMetadata);
    const [editing, setEditing] = useState<AutoRule>();
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState("");
    const library = ids.flatMap(id => {
        const cue = getSpell(id, true);
        return cue ? [{ id, name: cue.name, category: cue.audio.category, loop: cue.audio.loop,
            tags: soundTags(cue.audio.tags).map(tag => tag.toLowerCase()), embed: Boolean(sunoEmbedURL(cue.audio.url)) }] : [];
    });
    const musicTags = new Set(["music", ...library.flatMap(cue => cue.category === "music" ? cue.tags : [])]);
    const cues = library.filter(cue => !cue.embed);
    const players = useMemo(() => Array.from(new Map(
        [...(obr.player ? [obr.player] : []), ...obr.party].map(player => [player.id, player]),
    ).values()).sort((a, b) => a.name.localeCompare(b.name)), [obr.player, obr.party]);

    async function mutate(task: () => Promise<void>) {
        setError("");
        try { await task(); return true; }
        catch { setError("Couldn’t update the scene. Try again."); return false; }
    }

    if (!obr.sceneReady) return <p>Open a scene to set up audio triggers.</p>;
    return <section className="auto-panel">
        <div className="auto-heading">
            <h2>Rules</h2>
            {!editing && <button type="button" disabled={!config.triggers.length} onClick={() => {
                setEditing({ id: crypto.randomUUID(), triggerId: config.triggers[0].id, soundId: "",
                    start: config.triggers[0].kind === "line" ? "cross" : "enter", stop: "none",
                    loop: false, audience: "all", ripple: false, stopTags: [] });
            }}>Add new</button>}
        </div>
        {!config.triggers.length && <p>Press Shift+C and draw a line or region to create a trigger.</p>}
        {editing && <RuleForm key={editing.id} initial={editing} triggers={config.triggers} cues={cues} tags={[...musicTags]}
            saving={saving} cancel={() => setEditing(undefined)} save={async rule => {
                setSaving(true);
                const ok = await mutate(() => OBR.scene.setMetadata({ [RULE_PREFIX + rule.id]: rule }));
                setSaving(false);
                if (ok) setEditing(undefined);
            }}/>}
        {config.rules.length > 0 && <ul className="auto-list">
            {config.rules.map(rule => <RuleRow key={rule.id} rule={rule} trigger={config.triggers.find(item => item.id === rule.triggerId)!}
                cue={cues.find(cue => cue.id === rule.soundId)} tokens={tokens} edit={() => setEditing(rule)}
                remove={() => void mutate(async () => {
                    await OBR.scene.setMetadata({ [RULE_PREFIX + rule.id]: undefined });
                    if (editing?.id === rule.id) setEditing(undefined);
                })}
                play={tokenId => void mutate(() => OBR.broadcast.sendMessage(PLAY_RULE, { ruleId: rule.id, tokenId }, { destination: "ALL" }))}/>)}
        </ul>}
        {config.triggers.length > 0 && <details className="auto-card">
            <summary>Map triggers ({config.triggers.length})</summary>
            <ul className="auto-list">{config.triggers.map(trigger => {
                const attached = config.rules.filter(rule => rule.triggerId === trigger.id);
                return <li className="auto-heading" key={trigger.id}>
                    <span>{trigger.name} <small>{trigger.kind}</small></span>
                    <button type="button" disabled={attached.length > 0} title={attached.length ? "Remove its rules first" : "Remove trigger"}
                        aria-label={`Remove trigger ${trigger.name}`}
                        onClick={() => void mutate(() => OBR.scene.setMetadata({ [TRIGGER_PREFIX + trigger.id]: undefined }))}>Remove</button>
                </li>;
            })}</ul>
        </details>}
        <details className="auto-card">
            <summary>Audio-enabled tokens ({tokens.length})</summary>
            {!tokens.length && <p>Right-click a character token and choose Enable audio.</p>}
            <ul className="auto-list audio-form">{tokens.map(token => <li key={token.tokenId}>
                <label>{token.name}
                    <select aria-label={`Listener for ${token.name}`} value={token.userId} onChange={event => {
                        const userId = event.target.value;
                        void mutate(() => OBR.scene.items.updateItems([token.tokenId], ([item]) => {
                            if (item?.metadata[AUDIO_TOKEN]) item.metadata[AUDIO_TOKEN] = { userId };
                        }));
                    }}>
                        {!players.some(player => player.id === token.userId) && <option value={token.userId}>Current listener (offline)</option>}
                        {players.map(player => <option key={player.id} value={player.id}>{player.name}</option>)}
                    </select>
                </label>
            </li>)}</ul>
        </details>
        {error && <small role="alert">{error}</small>}
    </section>;
}
