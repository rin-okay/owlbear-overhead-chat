import { Dialog, DialogActions, DialogContent, DialogTitle, Button } from "@mui/material";
import { useState } from "react";
import { useAudioTokens } from "../auto/hooks";

export default function PlayFor({ cue, sceneReady, close, play }: {
    cue: string;
    sceneReady: boolean;
    close: () => void;
    play: (tokenIds: string[]) => Promise<void>;
}) {
    const tokens = useAudioTokens(sceneReady);
    const [checked, setChecked] = useState<Set<string>>(() => new Set());
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState(false);
    const selected = tokens.filter(token => checked.has(token.tokenId)).map(token => token.tokenId);

    return <Dialog open onClose={submitting ? undefined : close} fullWidth maxWidth="xs" aria-labelledby="play-for-title">
        <DialogTitle id="play-for-title">Play for</DialogTitle>
        <DialogContent>
            <p>{cue}</p>
            {!tokens.length && <small>No audio-enabled tokens.</small>}
            <div className="audio-form">
                {tokens.map(token => <label key={token.tokenId} className="check">
                    <input type="checkbox" checked={checked.has(token.tokenId)} disabled={submitting} onChange={event => {
                        const add = event.target.checked;
                        setChecked(old => {
                            const next = new Set(old);
                            if (add) next.add(token.tokenId);
                            else next.delete(token.tokenId);
                            return next;
                        });
                    }}/>{token.name}
                </label>)}
            </div>
            {error && <p role="alert">Couldn’t play this sound. Try again.</p>}
        </DialogContent>
        <DialogActions>
            <Button type="button" size="small" onClick={close} disabled={submitting}>Cancel</Button>
            <Button type="button" size="small" disabled={!selected.length || submitting} onClick={async () => {
                setSubmitting(true);
                setError(false);
                try { await play(selected); close(); }
                catch { setError(true); setSubmitting(false); }
            }}>Play</Button>
        </DialogActions>
    </Dialog>;
}
