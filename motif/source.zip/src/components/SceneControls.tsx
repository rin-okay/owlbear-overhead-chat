import "./SceneControls.css";

import { FaEye, FaEyeSlash, FaPause, FaPlay, FaSquareMinus } from "react-icons/fa6";
import OBR from "@owlbear-rodeo/sdk";
import { useState } from "react";
import { Typography } from "@mui/material";
import { ACTIVE_EFFECTS } from "../effects/audio";
import { CONTROL_CHANNEL, validClip } from "../effects/messageListener";
import type { ActiveEffect, Control } from "../types/messageListener";
import { useOBR } from "../react-obr/providers";

function send(request: Control) {
    return OBR.broadcast.sendMessage(CONTROL_CHANNEL, request, { destination: "ALL" });
}

function SpellDisplay({ item, gm }: { item: ActiveEffect; gm: boolean }) {
    const [edit, setEdit] = useState(false);
    const [error, setError] = useState("");
    const perform = (action: Control["action"]) => void send({ id: item.id, action }).catch(console.warn);
    return <li className="scene-spell-display-item">
        <div><p>{item.name}</p><small>{item.category === "music" ? "Music" : "SFX"} · {item.at === null ? "Paused" : "Playing"}{item.loop && " · Loop"}</small></div>
        {gm && <div className="scene-spell-display-controls">
            <button type="button" onClick={() => perform(item.at === null ? "resume" : "pause")}
                aria-label={item.at === null ? "Resume" : "Pause"} title={item.at === null ? "Resume" : "Pause"}>{item.at === null ? <FaPlay/> : <FaPause/>}</button>
            <button type="button" onClick={() => perform("hide")} aria-label={item.visible ? "Hide and mute" : "Show and unmute"}
                title={item.visible ? "Hide and mute" : "Show and unmute"}>{item.visible ? <FaEye/> : <FaEyeSlash/>}</button>
            <button type="button" onClick={() => setEdit(value => !value)}>Edit</button>
            <button type="button" onClick={() => perform("delete")} aria-label="Stop sound" title="Stop sound"><FaSquareMinus/></button>
        </div>}
        {edit && gm && <form className="audio-form" onSubmit={event => {
            event.preventDefault();
            const values = new FormData(event.currentTarget);
            const settings = { start: Number(values.get("start")), end: values.get("end") === "" ? null : Number(values.get("end")),
                volume: Number(values.get("volume")) / 100, loop: values.has("loop") };
            if (!validClip(settings)) { setError("Set the clip end after the start."); return; }
            void send({ action: "edit", id: item.id, settings }).then(() => setEdit(false)).catch(cause => setError(String(cause)));
        }}>
            <label>Start (s) <input name="start" type="number" min="0" step="any" required defaultValue={item.start}/></label>
            <label>End (s) <input name="end" type="number" min="0" step="any" defaultValue={item.end ?? ""}/></label>
            <label>Volume (%) <input name="volume" type="number" min="0" max="100" required defaultValue={Math.round(item.volume * 100)}/></label>
            <label className="check"><input name="loop" type="checkbox" defaultChecked={item.loop}/> Loop</label>
            <div><button type="submit">Save</button> <button type="button" onClick={() => setEdit(false)}>Cancel</button></div>
            {error && <p role="status">{error}</p>}
        </form>}
    </li>;
}

export default function SceneControls() {
    const obr = useOBR();
    const gm = obr.player?.role === "GM";
    const all = (obr.roomMetadata[ACTIVE_EFFECTS] as ActiveEffect[] | undefined) ?? [];
    const entries = gm ? all : all.filter(item => item.visible);
    return <section>
        <Typography variant="h6">Active sounds</Typography>
        {entries.length ? <ul className="scene-spell-list">
            {entries.map(item => <SpellDisplay key={item.id} item={item} gm={gm}/>)}
        </ul> : <p>No sounds playing.</p>}
    </section>;
}
