import "./CustomSpells.css";
import OBR from "@owlbear-rodeo/sdk";
import { useEffect, useState } from "react";
import { APP_KEY } from "../config";
import { constants } from "../constants";
import { getSpell } from "../effects/spells";
import { LIBRARY_CHANGED, sendSpellsUpdate } from "../effects/localSpells";
import { publicAudioURL, validClip } from "../effects/messageListener";
import { useOBR } from "../react-obr/providers";
import type { Spell } from "../types/spells";

function localIds(): string[] {
    return JSON.parse(localStorage.getItem(constants.SPELL_LIST_METADATA_KEY) ?? "[]");
}

async function saveSpellList(spellList: string[]) {
    localStorage.setItem(constants.SPELL_LIST_METADATA_KEY, JSON.stringify(spellList));
    if (await OBR.scene.isReady()) await OBR.scene.setMetadata({ [constants.SPELL_LIST_METADATA_KEY]: spellList });
    sendSpellsUpdate("all");
    await OBR.broadcast.sendMessage(LIBRARY_CHANGED, {}, { destination: "LOCAL" });
}

export default function CustomSpells() {
    const obr = useOBR();
    const [ids, setIds] = useState(localIds);
    const [editing, setEditing] = useState<string | undefined>();
    const [message, setMessage] = useState("");
    const [busy, setBusy] = useState(false);
    const spell = editing ? getSpell("$." + editing, true) : undefined;
    useEffect(() => OBR.broadcast.onMessage(LIBRARY_CHANGED, () => setIds(localIds())), []);
    if (!obr.ready || obr.player?.role !== "GM") return null;

    async function update(operation: () => Promise<void>) {
        setBusy(true);
        setMessage("");
        try { await operation(); setIds(localIds()); setEditing(undefined); }
        catch (error) { setMessage(error instanceof Error ? error.message : String(error)); }
        finally { setBusy(false); }
    }

    return <section>
        <h2>Custom sounds</h2>
        <button onClick={() => { setEditing(""); setMessage(""); }}>Add sound</button>
        <ul className="scene-spell-list">
            {ids.map(id => <li key={id} className="scene-spell-display-item">
                <p>{getSpell("$." + id, true)?.name} <small>{ "$." + id }</small></p>
                <div className="scene-spell-display-controls">
                    <button disabled={busy} onClick={() => setEditing(id)}>Edit</button>
                    <button disabled={busy} onClick={() => void update(async () => {
                        localStorage.removeItem(`${APP_KEY}/spells/${id}`);
                        await saveSpellList(localIds().filter(value => value !== id));
                    })}>Delete</button>
                </div>
            </li>)}
        </ul>
        {editing !== undefined && <form className="audio-form" key={editing} onSubmit={event => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            void update(async () => {
                const name = String(data.get("name")).trim();
                if (!name) throw Error("Enter a sound name.");
                const next: Spell = {
                    name,
                    audio: {
                        url: publicAudioURL(String(data.get("url")).trim()),
                        category: data.get("category") === "music" ? "music" : "effect",
                        tags: String(data.get("tags")).trim(),
                        start: Number(data.get("start")),
                        end: data.get("end") === "" ? null : Number(data.get("end")),
                        volume: Number(data.get("volume")) / 100,
                        loop: data.has("loop"),
                    }
                };
                if (!validClip(next.audio)) throw Error("Set the clip end after the start.");
                const id = editing || crypto.randomUUID().slice(0, 12);
                const ids = localIds();
                if (!editing && ids.length >= 50) throw Error("The library holds up to 50 custom sounds.");
                localStorage.setItem(`${APP_KEY}/spells/${id}`, JSON.stringify(next));
                await saveSpellList(ids.includes(id) ? ids : [...ids, id]);
            });
        }}>
            <label>Name <input name="name" required maxLength={80} defaultValue={spell?.name}/></label>
            <label>Public audio URL <input name="url" required type="url" maxLength={1200} defaultValue={spell?.audio.url}/></label>
            <label>Type <select name="category" defaultValue={spell?.audio.category ?? "effect"}><option value="effect">Effect</option><option value="music">Music</option></select></label>
            <label>Tags <input name="tags" maxLength={120} defaultValue={spell?.audio.tags}/></label>
            <label>Start (s) <input name="start" type="number" min="0" step="any" required defaultValue={spell?.audio.start ?? 0}/></label>
            <label>End (s) <input name="end" type="number" min="0" step="any" defaultValue={spell?.audio.end ?? ""}/></label>
            <label>Volume (%) <input name="volume" type="number" min="0" max="100" required defaultValue={Math.round((spell?.audio.volume ?? .65) * 100)}/></label>
            <label className="check"><input name="loop" type="checkbox" defaultChecked={spell?.audio.loop}/> Loop</label>
            <div><button disabled={busy} type="submit">Save sound</button> <button type="button" onClick={() => setEditing(undefined)}>Cancel</button></div>
        </form>}
        {message && <p role="status">{message}</p>}
    </section>;
}
