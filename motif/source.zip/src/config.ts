export const APP_KEY = "io.github.rin-okay.motif-v2";
export const ROOT = new URL(import.meta.env.BASE_URL, window.location.origin).href;
export const asset = (path: string) => new URL(path, ROOT).href;
