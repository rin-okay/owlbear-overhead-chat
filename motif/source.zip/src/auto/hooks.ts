import OBR from "@owlbear-rodeo/sdk";
import { useEffect, useState } from "react";
import { audioTokens, type AudioToken } from "./model";

export function useAudioTokens(ready: boolean) {
    const [tokens, setTokens] = useState<AudioToken[]>([]);
    useEffect(() => {
        if (!ready) { setTokens([]); return; }
        let seenUpdate = false;
        let live = true;
        const apply = (items: Awaited<ReturnType<typeof OBR.scene.items.getItems>>) => {
            const next = audioTokens(items).sort((a, b) => a.name.localeCompare(b.name));
            setTokens(old => JSON.stringify(old.map(({ tokenId, name, userId }) => [tokenId, name, userId])) ===
                JSON.stringify(next.map(({ tokenId, name, userId }) => [tokenId, name, userId])) ? old : next);
        };
        const stop = OBR.scene.items.onChange(items => { seenUpdate = true; apply(items); });
        void OBR.scene.items.getItems().then(items => { if (live && !seenUpdate) apply(items); }).catch(console.warn);
        return () => { live = false; stop(); };
    }, [ready]);
    return tokens;
}

