import type { ActiveEffect } from "../types/messageListener";
import type { Listener } from "./model";
import { soundTags } from "../effects/libraryFolders";

export function reaches(entry: ActiveEffect, userId: string) {
    return !entry.audience || entry.audience.listeners.some(listener => listener.userId === userId);
}

export function audible(entry: ActiveEffect, userId: string) {
    return entry.visible && (!entry.audience ||
        entry.audience.listeners.some(listener => listener.userId === userId && !listener.muted));
}

export function removeListeners(entry: ActiveEffect, tokenIds: Set<string>, current: Listener[]): ActiveEffect | undefined {
    if (!tokenIds.size) return entry;
    const listeners = (entry.audience?.listeners ?? current).filter(listener => !tokenIds.has(listener.tokenId));
    if (entry.audience && listeners.length === entry.audience.listeners.length) return entry;
    return listeners.length ? { ...entry, audience: { mode: "list", listeners } } : undefined;
}

export function stopMusic(entries: ActiveEffect[], listeners: Listener[], current: Listener[], tags?: string[]) {
    if (tags && !tags.length) return entries;
    const affected = new Set(listeners.map(listener => listener.tokenId));
    return entries.flatMap(entry => {
        if (entry.category !== "music" || (tags && !soundTags(entry.tags).some(tag => tags.includes(tag.toLowerCase())))) return [entry];
        return removeListeners(entry, affected, current) ?? [];
    });
}

export function reconcile(entry: ActiveEffect, current: Listener[]): ActiveEffect | undefined {
    const known = entry.audience?.listeners ?? [];
    const byId = new Map(known.map(listener => [listener.tokenId, listener]));
    const mode = entry.audience?.mode ?? "all";
    const listeners = current.filter(listener => mode === "all" || byId.has(listener.tokenId)).map(listener => {
        const old = byId.get(listener.tokenId);
        return old?.muted ? { ...listener, muted: true } : listener;
    });
    if (!listeners.length) return undefined;
    if (entry.audience && JSON.stringify(known) === JSON.stringify(listeners)) return entry;
    return { ...entry, audience: { mode, listeners } };
}
