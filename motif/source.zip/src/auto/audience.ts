import type { ActiveEffect } from "../types/messageListener";
import type { Listener } from "./model";
import { soundTags } from "../effects/libraryFolders";

export function reaches(entry: ActiveEffect, userId: string) {
    return !entry.audience || entry.audience.listeners.some(listener => listener.userId === userId);
}

export function audible(entry: ActiveEffect, userId: string, suppressed?: ReadonlySet<string>) {
    return entry.visible && (!entry.audience ||
        entry.audience.listeners.some(listener => listener.userId === userId && !listener.muted && !suppressed?.has(listener.tokenId)));
}

export function musicSuppressions(entries: ActiveEffect[]) {
    const result = new Map<string, Set<string>>();
    const reverse = [...entries].reverse().filter(entry => entry.visible && entry.at !== null);
    const tokens = new Set(reverse.flatMap(entry => entry.audience?.listeners.map(listener => listener.tokenId) ?? []));
    const entryTags = new Map(reverse.filter(entry => entry.category === "music")
        .map(entry => [entry.id, soundTags(entry.tags).map(tag => tag.toLowerCase())]));
    for (const tokenId of tokens) {
        const eligible = reverse.filter(entry => !entry.audience || entry.audience.listeners.some(listener =>
            listener.tokenId === tokenId && !listener.muted));
        const music = eligible.filter(entry => entry.category === "music");
        const force = music.find(entry => entry.forced);
        const suppress = (entry: ActiveEffect) => {
            const listeners = result.get(entry.id) ?? new Set<string>();
            listeners.add(tokenId);
            result.set(entry.id, listeners);
        };
        if (force) {
            music.forEach(entry => { if (entry !== force) suppress(entry); });
            continue;
        }

        const stopTags = new Set<string>();
        const matches = (entry: ActiveEffect) => entryTags.get(entry.id)?.some(tag => stopTags.has(tag));
        let automationPlaying = false;
        // Newer rules suppress matching older cues while the newer rule remains audible.
        for (const entry of eligible) {
            if (!entry.ruleId) continue;
            if (entry.category === "music") {
                if (matches(entry)) { suppress(entry); continue; }
                automationPlaying = true;
            }
            entry.stopMusicTags?.forEach(tag => stopTags.add(tag));
        }
        const manual = music.filter(entry => !entry.ruleId);
        const targeted = manual.find(entry => entry.targeted);
        for (const entry of manual) {
            if (automationPlaying || matches(entry) || (targeted && entry !== targeted)) suppress(entry);
        }
    }
    // One browser can listen through several tokens but has one music mix.
    const forcedUsers = new Set<string>();
    const autoUsers = new Set<string>();
    const targetedUsers = new Set<string>();
    for (const entry of reverse) {
        if (entry.category !== "music") continue;
        const users = entry.forced ? forcedUsers : entry.ruleId ? autoUsers : entry.targeted ? targetedUsers : undefined;
        if (!users) continue;
        for (const listener of entry.audience?.listeners ?? []) {
            if (!listener.muted && !result.get(entry.id)?.has(listener.tokenId)) users.add(listener.userId);
        }
    }
    for (const entry of reverse) {
        if (entry.category !== "music" || entry.forced) continue;
        for (const listener of entry.audience?.listeners ?? []) {
            const privateMusic = !entry.targeted && targetedUsers.has(listener.userId);
            if (!forcedUsers.has(listener.userId) && (entry.ruleId || (!autoUsers.has(listener.userId) && !privateMusic))) continue;
            const listeners = result.get(entry.id) ?? new Set<string>();
            listeners.add(listener.tokenId);
            result.set(entry.id, listeners);
        }
    }
    return result;
}

export function appendCue(entries: ActiveEffect[], cue: ActiveEffect) {
    if (entries.length < 20) return [...entries, cue];
    // Bound room metadata while keeping the manual return track and a forced override.
    const ordinary = entries.findIndex(entry => entry.category !== "music" || entry.ruleId);
    const oldest = ordinary < 0 ? entries.findIndex(entry => entry.targeted) : ordinary;
    return [...entries.filter((_entry, index) => index !== Math.max(0, oldest)), cue];
}

export function removeListeners(entry: ActiveEffect, tokenIds: Set<string>, current: Listener[]): ActiveEffect | undefined {
    if (!tokenIds.size) return entry;
    const listeners = (entry.audience?.listeners ?? current).filter(listener => !tokenIds.has(listener.tokenId));
    if (entry.audience && listeners.length === entry.audience.listeners.length) return entry;
    return listeners.length ? { ...entry, audience: { mode: "list", listeners } } : undefined;
}

export function reconcile(entry: ActiveEffect, current: Listener[]): ActiveEffect | undefined {
    const known = entry.audience?.listeners ?? [];
    const byId = new Map(known.map(listener => [listener.tokenId, listener]));
    const mode = entry.audience?.mode ?? "all";
    const listeners = current.filter(listener => mode === "all" || byId.has(listener.tokenId)).map(listener => {
        const old = byId.get(listener.tokenId);
        return old?.muted ? { ...listener, muted: true } : listener;
    });
    if (!listeners.length) return undefined;
    if (entry.audience && JSON.stringify(known) === JSON.stringify(listeners)) return entry;
    return { ...entry, audience: { mode, listeners } };
}
