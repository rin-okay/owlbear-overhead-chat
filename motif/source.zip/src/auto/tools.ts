import OBR, { buildCurve, type Curve, type Metadata, type Vector2 } from "@owlbear-rodeo/sdk";
import { APP_KEY, asset } from "../config";
import { log_error } from "../logging";
import { AUDIO_TOKEN, AVATAR, character, getAuto, type Trigger } from "./model";
import { validDrawing } from "./geometry";

export const NAME_TRIGGER = APP_KEY + "/name-trigger";
const LINE = APP_KEY + "/trigger-line";
const REGION = APP_KEY + "/trigger-region";
const FINISH = APP_KEY + "/finish-trigger";
const ENABLE = APP_KEY + "/enable-token-audio";

export function setupAudioContextMenu() {
    return OBR.contextMenu.create({
        id: ENABLE,
        icons: [
            { icon: asset("motif-wave.svg"), label: "Enable audio",
                filter: { min: 1, max: 1, permissions: ["UPDATE"], every: [
                    { key: "layer", value: "CHARACTER" }, { key: "type", value: "IMAGE" },
                    { key: ["metadata", AUDIO_TOKEN], value: undefined },
                ] } },
            { icon: asset("motif-wave.svg"), label: "Disable audio",
                filter: { min: 1, max: 1, permissions: ["UPDATE"], every: [
                    { key: "layer", value: "CHARACTER" }, { key: "type", value: "IMAGE" },
                    { key: ["metadata", AUDIO_TOKEN], value: undefined, operator: "!=" },
                ] } },
        ],
        onClick({ items }) {
            const token = items[0];
            if (!token || !character(token)) return;
            void (async () => {
                const [self, role, players, selfMetadata] = await Promise.all([
                    OBR.player.getId(), OBR.player.getRole(), OBR.party.getPlayers(), OBR.player.getMetadata(),
                ]);
                const avatar = (metadata: Metadata) => (metadata[AVATAR] as { tokenId?: string } | undefined)?.tokenId === token.id;
                const linked = players.find(player => avatar(player.metadata));
                const creator = token.createdUserId && players.find(player => player.id === token.createdUserId);
                const userId = role === "PLAYER" || avatar(selfMetadata) ? self :
                    linked?.id ?? (creator && creator.role === "PLAYER" ? creator.id : self);
                const disable = Boolean(token.metadata[AUDIO_TOKEN]);
                await OBR.scene.items.updateItems([token.id], ([item]) => {
                    if (!item || !character(item)) return;
                    if (disable) delete item.metadata[AUDIO_TOKEN];
                    else item.metadata[AUDIO_TOKEN] = { userId };
                });
            })().catch(log_error);
        },
    });
}

export function setupTriggerTools(toolId: string, defaultMode: string) {
    let kind: Trigger["kind"] | undefined;
    let points: Vector2[] = [];
    let hover: Vector2 | undefined;
    let lineStart: Vector2 | undefined;
    let sceneTriggers: Trigger[] = [];
    let refreshSaved = true;
    let busy = false;
    let closed = false;
    let dirty = false;
    let scheduled = false;
    let draftId: string | undefined;
    let savedIds: string[] = [];

    function curve(triggerPoints: Vector2[], polygon: boolean, draft: boolean, name: string) {
        return buildCurve().points(triggerPoints).closed(polygon).tension(0)
            .strokeColor(draft ? "#e4d8ff" : "#a591d5").strokeWidth(draft ? 4 : 3).strokeDash([10, 6])
            .fillColor("#ac96ec").fillOpacity(polygon ? .14 : 0).layer("POINTER").name(name)
            .locked(true).disableHit(true).build();
    }

    function render() {
        dirty = true;
        if (scheduled) return;
        scheduled = true;
        void (async () => {
            while (dirty) {
                dirty = false;
                if (closed || !kind) {
                    const ids = [...savedIds, ...(draftId ? [draftId] : [])];
                    savedIds = [];
                    refreshSaved = true;
                    draftId = undefined;
                    if (ids.length && await OBR.scene.isReady()) await OBR.scene.local.deleteItems(ids);
                    continue;
                }
                if (refreshSaved) {
                    refreshSaved = false;
                    if (savedIds.length) await OBR.scene.local.deleteItems(savedIds);
                    const items = sceneTriggers.map(trigger => curve(trigger.points, trigger.kind === "region", false, trigger.name));
                    savedIds = items.map(item => item.id);
                    if (items.length) await OBR.scene.local.addItems(items);
                }
                if (!kind || closed) continue;
                const preview = hover && points.length && (kind === "region" ? points.length < 64 : points.length === 1) ? [...points, hover] : points;
                if (preview.length < 2) {
                    if (draftId) await OBR.scene.local.deleteItems([draftId]);
                    draftId = undefined;
                    continue;
                }
                const polygon = kind === "region" && preview.length > 2;
                if (draftId) {
                    await OBR.scene.local.updateItems<Curve>([draftId], ([item]) => {
                        if (item?.type === "CURVE") {
                            item.points = preview;
                            item.style.closed = polygon;
                            item.style.fillOpacity = polygon ? .14 : 0;
                        }
                    });
                } else {
                    const item = curve(preview, polygon, true, "Motif trigger draft");
                    draftId = item.id;
                    await OBR.scene.local.addItems([item]);
                }
            }
        })().catch(log_error).finally(() => { scheduled = false; if (dirty) render(); });
    }

    function refresh(metadata: Metadata) {
        const next = getAuto(metadata).triggers;
        if (JSON.stringify(next) === JSON.stringify(sceneTriggers)) return;
        sceneTriggers = next;
        refreshSaved = true;
        if (kind) render();
    }

    function finish() {
        if (!kind || busy || closed) return;
        if (!validDrawing(kind, points)) {
            void OBR.notification.show(kind === "line" ? "Place two different endpoints first." : "Draw a region with at least three vertices and no crossing edges.");
            return;
        }
        const data = encodeURIComponent(JSON.stringify({ kind, points }));
        busy = true;
        void OBR.modal.open({
            id: NAME_TRIGGER, url: asset(`index.html?v=${__MOTIF_VERSION__}&panel=name-trigger#${data}`),
            width: 340, height: 185, hidePaper: true,
        }).then(() => {
            points = [];
            hover = undefined;
            render();
        }).catch(log_error).finally(() => { busy = false; });
    }

    const listening = OBR.scene.onMetadataChange(refresh);
    const register = async () => {
        refresh(await OBR.scene.getMetadata());
        for (const [id, shape] of [[LINE, "line"], [REGION, "region"]] as const) {
            if (closed) return;
            await OBR.tool.createMode({
                id, icons: [{ label: `Trigger definition (${shape})`, icon: asset(`trigger-${shape}.svg`), filter: { activeTools: [toolId], roles: ["GM"] } }],
                cursors: [{ cursor: "crosshair" }],
                onActivate() { kind = shape; points = []; hover = undefined; render(); },
                onDeactivate() { kind = undefined; points = []; hover = undefined; lineStart = undefined; render(); },
                onToolClick(_context, event) {
                    if (busy || closed || (shape === "region" && points.length >= 64)) return false;
                    if (shape === "line" && points.length === 2) points = [];
                    points = [...points, event.pointerPosition];
                    render();
                    return false;
                },
                onToolMove(_context, event) {
                    if (!points.length || (shape === "line" && points.length === 2)) return;
                    hover = event.pointerPosition;
                    render();
                },
                ...(shape === "line" ? {
                    onToolDragStart(_context, event) { lineStart = event.pointerPosition; points = [lineStart]; render(); },
                    onToolDragMove(_context, event) { if (lineStart) { hover = event.pointerPosition; render(); } },
                    onToolDragEnd(_context, event) { if (lineStart) { points = [lineStart, event.pointerPosition]; lineStart = undefined; render(); } },
                    onToolDragCancel() { lineStart = undefined; points = []; hover = undefined; render(); },
                } satisfies Partial<import("@owlbear-rodeo/sdk").ToolMode> : {}),
                onKeyDown(_context, event) {
                    if (event.key === "Enter" && !event.repeat) finish();
                    if (event.key === "Backspace") { points = points.slice(0, -1); hover = undefined; render(); }
                    if (event.key === "Escape") void OBR.tool.activateMode(toolId, defaultMode).catch(log_error);
                },
            });
            if (closed) await OBR.tool.removeMode(id);
        }
        if (closed) return;
        await OBR.tool.createAction({
            id: FINISH, icons: [{ label: "Finish drawing", icon: asset("cast.svg"), filter: {
                activeTools: [toolId], activeModes: [LINE, REGION], roles: ["GM"],
            } }],
            onClick: finish,
        });
        if (closed) await OBR.tool.removeAction(FINISH);
    };
    void register().catch(log_error);
    return () => {
        closed = true;
        listening();
        render();
        void OBR.modal.close(NAME_TRIGGER).catch(log_error);
        void Promise.all([OBR.tool.removeAction(FINISH), OBR.tool.removeMode(LINE), OBR.tool.removeMode(REGION)]).catch(log_error);
    };
}
