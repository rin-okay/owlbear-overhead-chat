import type { Item, Metadata, Vector2 } from "@owlbear-rodeo/sdk";
import { APP_KEY } from "../config";

export const TRIGGER_PREFIX = APP_KEY + "/trigger/";
export const RULE_PREFIX = APP_KEY + "/rule/";
export const AUDIO_TOKEN = APP_KEY + "/audio-token";
export const PLAY_RULE = APP_KEY + "/play-rule";
export const AVATAR = "chat.overhead.avatar.v1";

export type Trigger = { id: string; name: string; kind: "line" | "region"; points: Vector2[] };
export type TriggerEvent = "enter" | "exit" | "cross";
export type AutoRule = {
    id: string;
    triggerId: string;
    soundId: string;
    start: TriggerEvent | "none";
    stop: TriggerEvent | "none";
    loop: boolean;
    audience: "all" | "token";
    ripple: boolean;
    stopTags: string[];
};
export type AutoConfig = { triggers: Trigger[]; rules: AutoRule[] };
export type Listener = { tokenId: string; name: string; userId: string; muted?: boolean };
export type AudioToken = Listener & { position: Vector2 };

export function getAuto(metadata: Metadata): AutoConfig {
    const triggers = Object.entries(metadata).flatMap(([key, value]) => key.startsWith(TRIGGER_PREFIX) && value ? [value as Trigger] : []);
    const ids = new Set(triggers.map(trigger => trigger.id));
    const rules = Object.entries(metadata).flatMap(([key, value]) => key.startsWith(RULE_PREFIX) && value &&
        ids.has((value as AutoRule).triggerId) ? [value as AutoRule] : []);
    return { triggers, rules };
}

export function character(item: Item) {
    return item.layer === "CHARACTER" && item.type === "IMAGE";
}

export function audioTokens(items: Item[]): AudioToken[] {
    return items.flatMap(item => {
        const enabled = item.metadata[AUDIO_TOKEN] as { userId?: string } | undefined;
        return character(item) && enabled?.userId ? [{
            tokenId: item.id, userId: enabled.userId, name: item.name || "Character", position: item.position,
        }] : [];
    });
}

export function listenerOf({ tokenId, userId, name }: AudioToken): Listener {
    return { tokenId, userId, name };
}

export function triggerEvents(kind: Trigger["kind"]): TriggerEvent[] {
    return kind === "region" ? ["enter", "exit"] : ["cross"];
}
