import type { Vector2 } from "@owlbear-rodeo/sdk";
import type { Trigger, TriggerEvent } from "./model";

const EPSILON = 1e-7;
const delta = (a: Vector2, b: Vector2) => ({ x: a.x - b.x, y: a.y - b.y });
const cross = (a: Vector2, b: Vector2) => a.x * b.y - a.y * b.x;
const at = (a: Vector2, b: Vector2, t: number) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
const same = (a: Vector2, b: Vector2) => Math.hypot(a.x - b.x, a.y - b.y) < EPSILON;

function intersection(a: Vector2, b: Vector2, p: Vector2, q: Vector2) {
    const travel = delta(b, a), edge = delta(q, p), offset = delta(p, a);
    const denominator = cross(travel, edge);
    if (Math.abs(denominator) < EPSILON) return;
    const t = cross(offset, edge) / denominator, u = cross(offset, travel) / denominator;
    if (t >= -EPSILON && t <= 1 + EPSILON && u >= -EPSILON && u <= 1 + EPSILON) {
        return Math.max(0, Math.min(1, t));
    }
}

export function inside(point: Vector2, polygon: Vector2[]) {
    let hit = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const a = polygon[j], b = polygon[i];
        if (Math.abs(cross(delta(point, a), delta(b, a))) < EPSILON &&
            point.x >= Math.min(a.x, b.x) && point.x <= Math.max(a.x, b.x) &&
            point.y >= Math.min(a.y, b.y) && point.y <= Math.max(a.y, b.y)) return false;
        if ((a.y > point.y) !== (b.y > point.y) &&
            point.x < a.x + (point.y - a.y) * (b.x - a.x) / (b.y - a.y)) hit = !hit;
    }
    return hit;
}

export function validDrawing(kind: Trigger["kind"], points: Vector2[]) {
    if (!points.every(point => Number.isFinite(point.x) && Number.isFinite(point.y))) return false;
    if (kind === "line") return points.length === 2 && !same(points[0], points[1]);
    if (points.length < 3 || points.length > 64 || points.some((point, i) => points.slice(i + 1).some(other => same(point, other)))) return false;
    for (let i = 0; i < points.length; i++) {
        for (let j = i + 2; j < points.length; j++) {
            if (i === 0 && j === points.length - 1) continue;
            if (intersection(points[i], points[(i + 1) % points.length], points[j], points[(j + 1) % points.length]) !== undefined) return false;
        }
    }
    return Math.abs(points.reduce((area, point, i) => area + cross(point, points[(i + 1) % points.length]), 0)) > EPSILON;
}

export type Crossing = { event: TriggerEvent; t: number; position: Vector2 };

export function movement(trigger: Trigger, a: Vector2, b: Vector2): Crossing[] {
    if (same(a, b)) return [];
    const { points } = trigger;
    if (trigger.kind === "line") {
        const t = intersection(a, b, points[0], points[1]);
        // Count arrival on the wire once. Departing from it does not retrigger.
        return t !== undefined && t > EPSILON ? [{ event: "cross", t, position: at(a, b, t) }] : [];
    }
    const cuts = [0, 1];
    for (let i = 0; i < points.length; i++) {
        const t = intersection(a, b, points[i], points[(i + 1) % points.length]);
        if (t !== undefined && !cuts.some(existing => Math.abs(existing - t) < EPSILON)) cuts.push(t);
    }
    cuts.sort((x, y) => x - y);
    const events: Crossing[] = [];
    let wasInside = inside(a, points);
    function compare(isInside: boolean, t: number) {
        if (isInside !== wasInside) events.push({ event: isInside ? "enter" : "exit", t, position: at(a, b, t) });
        wasInside = isInside;
    }
    cuts.slice(0, -1).forEach((t, i) => compare(inside(at(a, b, (t + cuts[i + 1]) / 2), points), t));
    compare(inside(b, points), 1);
    return events;
}
