import OBR from "@owlbear-rodeo/sdk";
import type { Vector2 } from "@owlbear-rodeo/sdk";
import { inside, movement } from "./geometry";
import { audioTokens, getAuto, listenerOf } from "./model";
import type { AudioToken, AutoConfig, AutoRule, Listener } from "./model";
import { reconcile, removeListeners, stopMusic } from "./audience";
import type { ActiveEffect } from "../types/messageListener";

export function startRule(entries: ActiveEffect[], rule: AutoRule, token: AudioToken | undefined, tokens: AudioToken[],
    position: Vector2, create: () => ActiveEffect | undefined) {
    const all = tokens.map(listenerOf);
    const recipients = rule.audience === "all" ? all : token ? [listenerOf(token)] : [];
    if (!recipients.length) return entries;
    const existing = rule.loop ? entries.find(entry => entry.ruleId === rule.id && entry.loop) : undefined;
    const added = recipients.filter(listener => !existing?.audience?.listeners.some(old => old.tokenId === listener.tokenId));
    if (!added.length) return entries;
    const clip = existing ?? create();
    if (!clip) return entries;
    const other = stopMusic(entries.filter(entry => entry !== existing), added, all, rule.stopTags);
    const ripple = rule.ripple ? { id: crypto.randomUUID(), at: Date.now(), position, tokenId: token && rule.audience === "token" ? token.tokenId : undefined } : undefined;
    return [...other.slice(-19), {
        ...clip, loop: rule.loop, ruleId: rule.id, ripple,
        audience: {
            mode: existing?.audience?.mode ?? (rule.audience === "all" ? "all" : "list"),
            listeners: [...existing?.audience?.listeners ?? [], ...added],
        },
    }];
}

export function evaluateMovement(entries: ActiveEffect[], config: AutoConfig, previous: AudioToken[], current: AudioToken[],
    create: (rule: AutoRule) => ActiveEffect | undefined) {
    const last = new Map(previous.map(token => [token.tokenId, token.position]));
    const moved = current.filter(token => {
        const point = last.get(token.tokenId);
        return point && (point.x !== token.position.x || point.y !== token.position.y);
    });
    const listeners = current.map(listenerOf);
    for (const trigger of config.triggers) {
        const rules = config.rules.filter(rule => rule.triggerId === trigger.id);
        if (!rules.length) continue;
        const occupants = new Set(trigger.kind === "region" ? current.filter(token => inside(
            last.get(token.tokenId) ?? token.position, trigger.points)).map(token => token.tokenId) : []);
        const events = moved.flatMap(token => movement(trigger, last.get(token.tokenId)!, token.position)
            .map(crossing => ({ ...crossing, token }))).sort((a, b) => a.t - b.t);
        for (let i = 0; i < events.length;) {
            const first = events[i];
            let end = i + 1;
            while (end < events.length && Math.abs(events[end].t - first.t) < 1e-7) end++;
            const before = occupants.size;
            const group = events.slice(i, end);
            for (const hit of group) {
                if (hit.event === "enter") occupants.add(hit.token.tokenId);
                if (hit.event === "exit") occupants.delete(hit.token.tokenId);
            }
            for (const rule of rules) {
                const allEvent = trigger.kind === "line" ? group[0] : before === 0 && occupants.size
                    ? group.find(hit => hit.event === "enter")
                    : before && occupants.size === 0 ? group.find(hit => hit.event === "exit") : undefined;
                for (const hit of rule.audience === "all" ? (allEvent ? [allEvent] : []) : group) {
                    const applies = (entry: ActiveEffect) => entry.ruleId === rule.id &&
                        (rule.audience === "all" || entry.audience?.listeners.some(listener => listener.tokenId === hit.token.tokenId));
                    const playing = entries.some(applies);
                    if (playing && rule.stop === hit.event) {
                        entries = entries.flatMap(entry => !applies(entry) ? [entry] : rule.audience === "all" ? [] :
                            removeListeners(entry, new Set([hit.token.tokenId]), listeners) ?? []);
                    } else if (rule.start === hit.event) {
                        entries = startRule(entries, rule, hit.token, current, hit.position, () => create(rule));
                    }
                }
            }
            i = end;
        }
    }
    return entries;
}

type SceneUpdate = (config: AutoConfig | null, current: AudioToken[], previous: AudioToken[] | undefined) => void;

export function watchTriggers(update: SceneUpdate, prefetch: (config: AutoConfig) => void) {
    let epoch = 0;
    let config: AutoConfig | undefined;
    let previous: AudioToken[] | undefined;
    let cleanups: (() => void)[] = [];

    function scene(ready: boolean) {
        const version = ++epoch;
        cleanups.forEach(cleanup => cleanup());
        cleanups = [];
        config = undefined;
        previous = undefined;
        if (!ready) { update(null, [], undefined); return; }
        let latest: AudioToken[] | undefined;
        const publish = () => {
            if (!config || !latest) return;
            update(config, latest, previous);
            previous = latest;
        };
        const metadata = (value: Awaited<ReturnType<typeof OBR.scene.getMetadata>>) => {
            if (version !== epoch) return;
            config = getAuto(value);
            prefetch(config);
            publish();
        };
        const items = (value: Awaited<ReturnType<typeof OBR.scene.items.getItems>>) => {
            if (version !== epoch) return;
            const next = audioTokens(value).sort((a, b) => a.tokenId.localeCompare(b.tokenId));
            if (JSON.stringify(next) === JSON.stringify(latest)) return;
            latest = next;
            publish();
        };
        cleanups = [OBR.scene.onMetadataChange(metadata), OBR.scene.items.onChange(items)];
        void OBR.scene.getMetadata().then(value => { if (!config) metadata(value); }).catch(console.warn);
        void OBR.scene.items.getItems().then(value => { if (!latest) items(value); }).catch(console.warn);
    }

    OBR.scene.onReadyChange(scene);
    void OBR.scene.isReady().then(ready => { if (!epoch && ready) scene(true); }).catch(console.warn);
    return {
        refreshLibrary() { if (config) prefetch(config); },
        refreshAuthority() { if (config && previous) update(config, previous, undefined); },
    };
}

export function reconcileScene(entries: ActiveEffect[], config: AutoConfig, current: AudioToken[], previous?: AudioToken[]) {
    const listeners: Listener[] = current.map(listenerOf);
    const isFirstUpdate = !previous;
    return entries.flatMap(entry => {
        if (entry.ruleId) {
            const rule = config.rules.find(rule => rule.id === entry.ruleId);
            if (!rule) return [];
            const trigger = config.triggers.find(trigger => trigger.id === rule.triggerId);
            if (!trigger) return [];
            // Removing the last token from a region also stops its room-wide exit cue.
            if (!isFirstUpdate && rule.audience === "all" && rule.stop === "exit" && trigger.kind === "region") {
                const formerOccupants = previous.filter(token => inside(token.position, trigger.points));
                if (formerOccupants.length && !formerOccupants.some(old => current.some(token => token.tokenId === old.tokenId)) &&
                    !current.some(token => inside(token.position, trigger.points))) return [];
            }
        }
        return reconcile(entry, listeners) ?? [];
    });
}
