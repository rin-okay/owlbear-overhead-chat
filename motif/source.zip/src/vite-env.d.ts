/// <reference types="vite/client" />

declare const __MOTIF_VERSION__: string;
