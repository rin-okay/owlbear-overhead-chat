import { GLOBAL_STORAGE_KEYS, LOCAL_STORAGE_KEYS, getGlobalSettingsValue, getSettingsValue } from "./components/Settings/settings";
import OBR, { Image, Item, Vector2, buildImage, isImage } from "@owlbear-rodeo/sdk";

import { APP_KEY, asset } from "./config";
import { doSpell } from "./effects/spells";
import { PREFETCH } from "./effects/audio";
import { getItemSize } from "./utils";
import { log_error } from "./logging";
export const spellPopoverId = `${APP_KEY}/spell-popover`;

export const toolID = `${APP_KEY}/effect-tool`;
export const toolMetadataSelectedSpell = `${APP_KEY}/selected-spell`;
export const effectsToolModeID = `${APP_KEY}/effects-tool-mode`;
export const removeTargetToolModeID = `${APP_KEY}/remove-effects-tool-mode`;
export const effectsToolActionID = `${APP_KEY}/effects-tool-action`;
export const settingsToolActionID = `${APP_KEY}/settings-tool-action`;
export const selectSpellToolActionID = `${APP_KEY}/select-spell-tool-action`;
export const clearTargetSelectionToolActionID = `${APP_KEY}/clear-target-selection-tool-action`;
export const targetHighlightMetadataKey = `${APP_KEY}/target-highlight`;
export const previousToolMetadataKey = `${APP_KEY}/previous-tool`;
export const playerSelectedTargetsMetadataKey = `${APP_KEY}/selected-targets`;


export interface TargetHighlightMetadata {
    id: number;
    count: number;
}

function deactivateTool() {
    OBR.scene.local.getItems().then(items => {
        const targets = items.filter(item => item.metadata[targetHighlightMetadataKey] != undefined);
        OBR.scene.local.deleteItems(targets.map(item => item.id));
        OBR.player.setMetadata({
            [playerSelectedTargetsMetadataKey]: targets.map(target => ({
                item: target,
                count: getTargetCount(target),
                id: getTargetID(target)
            }))
        });
    });
}

function buildTarget(id: number, scale: number, position: Vector2, isFirst: boolean, attachedTo?: string, count?: number) {
    const target = buildImage(
        {
            url: asset((isFirst ? "first-" : "") + "target.svg"),
            width: 1000,
            height: 1000,
            mime: "image/svg+xml"
        },
        {
            dpi: 1000,
            offset: { x: 500, y: 500 }
        }
    ).scale(
        { x: scale, y: scale },
    ).position(
        position
    ).locked(
        true
    ).disableHit(
        attachedTo != undefined
    ).metadata({
        [targetHighlightMetadataKey]: {
            id,
            count: count ?? 1
        }
    });
    if (attachedTo != undefined) {
        target.attachedTo(attachedTo);
    }
    if (count != undefined && count != 1) {
        target.plainText(count.toString());
    }
    return target.build();
}

async function incrementTargetCount(target: Image) {
    await OBR.scene.local.updateItems<Image>([target.id], items => {
        for (const item of items) {
            const newCount = (getTargetCount(item) ?? 0) + 1;
            item.metadata[targetHighlightMetadataKey] = {
                count: newCount,
                id: getTargetID(item)
            };
            if (newCount > 1) {
                item.text.plainText = newCount.toString();
            }
        }
    });
}

async function removeTarget(target: Image, targets: Image[]) {
    if (targets.length >= 2 && getTargetID(target) == getTargetID(targets[0])) {
        OBR.scene.local.updateItems<Image>([targets[1].id], items => {
            if (items[0]) {
                items[0].image.url = asset("first-target.svg");
            }
        });
    }
    OBR.scene.local.deleteItems([target.id]);
}

export async function setSelectedSpell(spellName: string) {
    // Set selected spell
    await OBR.player.setMetadata({ [toolMetadataSelectedSpell]: spellName });
    void OBR.broadcast.sendMessage(PREFETCH, spellName, { destination: "LOCAL" }).catch(log_error);
    if (await OBR.scene.isReady()) void OBR.tool.setMetadata(toolID, { [toolMetadataSelectedSpell]: spellName }).catch(log_error);
}

export function getTargetHighlightMetadata(item: Item): TargetHighlightMetadata|undefined {
    const highlightMetadata = item.metadata[targetHighlightMetadataKey];
    if (highlightMetadata == undefined) {
        return undefined;
    }
    const thmHighlightMetadata = highlightMetadata as TargetHighlightMetadata;
    if (typeof thmHighlightMetadata.id !== "number" || typeof thmHighlightMetadata.count !== "number") {
        return undefined;
    }
    return thmHighlightMetadata;
}

export function getTargetID(item: Item) {
    return getTargetHighlightMetadata(item)?.id;
}

export function getTargetCount(item: Item) {
    return getTargetHighlightMetadata(item)?.count;
}

export async function getSortedTargets() {
    const items = await OBR.scene.local.getItems();
    return items.filter(
        item => isImage(item) && getTargetHighlightMetadata(item) != undefined
    ).sort(
        (a, b) => (getTargetID(a) ?? 0) - (getTargetID(b) ?? 0)
    ) as Image[];
}

async function getPointerPosition(position: Vector2, snapToGrid: boolean) {
    if (snapToGrid) {
        return OBR.scene.grid.snapPosition(position);
    }
    return position;
}

export function setupEffectsTool(playerRole: "GM" | "PLAYER", playerID: string) {
    let active = true;
    void OBR.player.getMetadata().then(async metadata => {
        if (!active) return;
        await OBR.tool.create({
            id: toolID,
            defaultMode: effectsToolModeID,
            defaultMetadata: {
                [toolMetadataSelectedSpell]: metadata[toolMetadataSelectedSpell],
            },
            icons: [{
                icon: asset("motif.svg"),
                label: "Play sound"
            }],
            shortcut: "Shift+C",
            onClick(context) {
                if (context.activeTool === toolID) {
                    // de-select
                    OBR.player.getMetadata().then(metadata => {
                        const previousTool = metadata?.[previousToolMetadataKey] as string | undefined;
                        if (previousTool != undefined) {
                            OBR.tool.activateTool(previousTool);
                        }
                    })
                    return false;
                }
                OBR.player.setMetadata({ [previousToolMetadataKey]: context.activeTool });
                return true;
            }
        });
        if (!active) return;
        await setupTargetToolModes();
        if (active) await setupToolActions(playerRole, playerID);
    }).catch(log_error);
    const unsubscribe = OBR.tool.onToolChange(tool => {
        if (tool == toolID && getSettingsValue(LOCAL_STORAGE_KEYS.KEEP_SELECTED_TARGETS)) {
            OBR.player.getMetadata().then(metadata => {
                const oldTargets = metadata[playerSelectedTargetsMetadataKey] as { item: Item, count: number, id: number }[];
                if (oldTargets == undefined) {
                    return;
                }
                const minTargetId = Math.min(...oldTargets.map(target => target.id));
                for (const target of oldTargets) {
                    const targetHighlight = buildTarget(
                        target.id,
                        target.item.scale.x,
                        target.item.position,
                        target.id === minTargetId,
                        target.item.attachedTo,
                        target.count
                    );
                    OBR.scene.local.addItems([targetHighlight]);
                }
            });
        }
    });
    return () => {
        active = false;
        unsubscribe();
        void OBR.tool.remove(toolID).catch(log_error);
    };
}

async function setupToolActions(playerRole: "GM" | "PLAYER", playerID: string) {
    // Play sound action
    await OBR.tool.createAction({
        id: effectsToolActionID,
        icons: [{
            icon: asset("cast.svg"),
            label: "Play Selected Sound",
            filter: {
                activeTools: [toolID],
            },
        }],
        disabled: {
            metadata: [{
                key: toolMetadataSelectedSpell,
                value: undefined,
            }]
        },
        shortcut: "Enter",
        onClick() {
            Promise.all([OBR.player.getMetadata(), getGlobalSettingsValue(GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS)]).then(([metadata, canCastSpells]) => {
                if (!canCastSpells && playerRole !== "GM") {
                    OBR.notification.show("Motif: You do not have permission to play sounds", "ERROR");
                    return;
                }
                if (typeof metadata[toolMetadataSelectedSpell] != "string") {
                    log_error(`Invalid spell selected ("${metadata?.[toolMetadataSelectedSpell]}")`);
                    OBR.notification.show(`Motif: Invalid spell selected ("${metadata?.[toolMetadataSelectedSpell]}")`, "ERROR");
                    return;
                }
                void doSpell(metadata[toolMetadataSelectedSpell], playerID, playerRole === "GM").catch(log_error);
            });
        }
    });

    // Select spell action
    await OBR.tool.createAction({
        id: selectSpellToolActionID,
        icons: [{
            icon: asset("pick-spell.svg"),
            label: "Select Sound",
            filter: {
                activeTools: [toolID]
            }
        }],
        shortcut: ".",
        onClick() {
            // Open popup to select a spell
            OBR.popover.open({
                id: spellPopoverId,
                width: 500,
                height: 300,
                url: asset("index.html?panel=select"),
                hidePaper: true
            });
        }
    });

    // Clear target selection action
    await OBR.tool.createAction({
        id: clearTargetSelectionToolActionID,
        icons: [{
            icon: asset("remove-selection.svg"),
            label: "Clear Target Selection",
            filter: {
                activeTools: [toolID]
            }
        }],
        shortcut: "x",
        onClick() {
            OBR.scene.local.getItems().then(items => {
                const targets = items.filter(item => item.metadata[targetHighlightMetadataKey] != undefined);
                OBR.scene.local.deleteItems(targets.map(item => item.id));
            });
        }
    });
}

async function setupTargetToolModes() {
    await OBR.tool.createMode({
        id: effectsToolModeID,
        icons: [{
            icon: asset("target.svg"),
            label: "Add Targets",
            filter: {
                activeTools: [toolID]
            }
        }],
        cursors: [{
            cursor: "pointer",
            filter: {
                target: [
                    {
                        key: "layer", value: "CHARACTER", coordinator: "||"
                    },
                    {
                        key: "layer", value: "DRAWING"
                    },
                ]
            }
        }],
        shortcut: "A",
        onToolClick(_context, event) {
            // User is clicking on an object, and not in free mode (shift)
            if (!event.shiftKey && event.target && (event.target.layer == "CHARACTER" || event.target.layer == "DRAWING")) {
                getSortedTargets().then(targets => {
                    const selected: Image|undefined = targets.filter(image => image.attachedTo === event.target!.id)[0];

                    if (!selected) {
                        const targetHighlight = buildTarget(
                            ((targets.length > 0 ? getTargetID(targets[targets.length-1]) : undefined) ?? 0) + 1,
                            getItemSize(event.target!) * 1.31,
                            event.target!.position,
                            targets.length == 0,
                            event.target!.id
                        );
                        OBR.scene.local.addItems([targetHighlight]);
                    }
                    else {
                        incrementTargetCount(selected);
                    }
                });
            }
            // User is clicking on a free target
            else if (!event.shiftKey && event.target && getTargetHighlightMetadata(event.target) != undefined) {
                incrementTargetCount(event.target! as Image);
            }
            // No target is being selected, just a position
            else {
                Promise.all([
                    getSortedTargets(),
                    getPointerPosition(event.pointerPosition, !event.shiftKey)
                ]).then(([targets, position]) => {
                    const targetHighlight = buildTarget(
                        ((targets.length > 0 ? getTargetID(targets[targets.length-1]) : undefined) ?? 0) + 1,
                        2 / 3,
                        position,
                        targets.length == 0
                    );
                    OBR.scene.local.addItems([targetHighlight]);
                });
            }
        },
        onDeactivate(context) {
            if (context.activeTool != toolID || context.activeMode != removeTargetToolModeID) {
                deactivateTool();
            }
        }
    });
    await OBR.tool.createMode({
        id: removeTargetToolModeID,
        icons: [{
            icon: asset("remove-target.svg"),
            label: "Remove Targets",
            filter: {
                activeTools: [toolID]
            }
        }],
        cursors: [{
            cursor: "pointer",
            filter: {
                target: [
                    {
                        key: "layer", value: "CHARACTER", coordinator: "||"
                    },
                    {
                        key: "layer", value: "DRAWING"
                    },
                ]
            }
        }],
        shortcut: "R",
        onToolClick(_context, event) {
            // User clicked on an object with an attached target
            if (event.target && (event.target.layer == "CHARACTER" || event.target.layer == "DRAWING")) {
                getSortedTargets().then(targets => {
                    const selected: Image|undefined = targets.filter(image => image.attachedTo === event.target!.id)[0];
                    if (selected != undefined) {
                        removeTarget(selected, targets);
                    }
                });
            }
            // User clicked on a free target
            else if (event.target && getTargetHighlightMetadata(event.target) != undefined) {
                getSortedTargets().then(targets => {
                    removeTarget(event.target! as Image, targets);
                });
            }
        },
        onDeactivate(context) {
            if (context.activeTool != toolID || context.activeMode != effectsToolModeID) {
                deactivateTool();
            }
        }
    });
}

