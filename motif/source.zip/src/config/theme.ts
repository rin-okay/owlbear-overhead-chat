import { createTheme } from "@mui/material/styles";

export const darkTheme = createTheme({
    palette: {
        mode: "dark",
        primary: { main: "#c7b6f8", contrastText: "#271c3a" },
        text: { primary: "#f5efff", secondary: "#ab9dbb" },
        background: { default: "transparent", paper: "transparent" },
    },
    typography: { fontFamily: "system-ui, sans-serif" },
});
