import OBR from "@owlbear-rodeo/sdk";
import { APP_KEY, asset } from "./config";

export const SUNO_POPOVER = APP_KEY + "/suno-player";
export const SUNO_EXPAND = SUNO_POPOVER + "/expand";
const expanded = { width: 430, height: 330 };
const minimized = { width: 270, height: 42 };

export function isSunoPage(url: URL) {
    return url.hostname === "suno.com" || url.hostname === "www.suno.com";
}

export function sunoEmbedURL(value: string): string | undefined {
    let url: URL;
    try { url = new URL(value); }
    catch { return; }
    if (url.protocol !== "https:" || url.username || url.password || url.port || !isSunoPage(url)) return;
    const id = /^\/(?:embed|song)\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/?$/i.exec(url.pathname)?.[1];
    return id ? "https://suno.com/embed/" + id.toLowerCase() : undefined;
}

export async function resizeSunoPlayer(collapse: boolean) {
    const { width, height } = collapse ? minimized : expanded;
    await OBR.popover.setWidth(SUNO_POPOVER, width);
    await OBR.popover.setHeight(SUNO_POPOVER, height);
}

export async function openSunoPlayer() {
    // Reuse the existing iframe when a listener opens the shared track again.
    if (await OBR.popover.getHeight(SUNO_POPOVER) !== undefined) {
        return OBR.broadcast.sendMessage(SUNO_EXPAND, {}, { destination: "LOCAL" });
    }
    const height = await OBR.viewport.getHeight();
    return OBR.popover.open({
        id: SUNO_POPOVER,
        url: asset("index.html?v=0.2.7&panel=suno"),
        ...expanded,
        anchorReference: "POSITION",
        anchorPosition: { left: 16, top: height - 16 },
        transformOrigin: { horizontal: "LEFT", vertical: "BOTTOM" },
        hidePaper: true,
        disableClickAway: true,
    });
}
