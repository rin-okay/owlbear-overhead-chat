import OBR from "@owlbear-rodeo/sdk";
import { APP_KEY, asset } from "./config";

export const SUNO_POPOVER = APP_KEY + "/suno-player";

export function isSunoPage(url: URL) {
    return url.hostname === "suno.com" || url.hostname === "www.suno.com";
}

export function sunoEmbedURL(value: string): string | undefined {
    let url: URL;
    try { url = new URL(value); }
    catch { return; }
    if (url.protocol !== "https:" || url.username || url.password || url.port || !isSunoPage(url)) return;
    const id = /^\/(?:embed|song)\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/?$/i.exec(url.pathname)?.[1];
    return id ? "https://suno.com/embed/" + id.toLowerCase() : undefined;
}

export function openSunoPlayer() {
    return OBR.popover.open({
        id: SUNO_POPOVER,
        url: asset("index.html?v=0.2.5&panel=suno"),
        width: 430,
        height: 330,
        anchorReference: "POSITION",
        anchorPosition: { left: 16, top: 120 },
        hidePaper: true,
        disableClickAway: true,
    });
}
