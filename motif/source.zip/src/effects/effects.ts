export function prefetchAssets(assets: string[]) {
    const fetches = assets.map(async asset => {
        const response = await fetch(
            asset,
            { cache: "force-cache", credentials: "omit", signal: AbortSignal.timeout(15000) }
        );
        const size = Number(response.headers.get("content-length"));
        const type = response.headers.get("content-type") ?? "";
        if (!response.ok || !Number.isFinite(size) || size <= 0 || size > 20_000_000 ||
            !/^(audio\/|application\/(octet-stream|ogg))/i.test(type)) throw Error("Could not cache audio");
        return await response.blob(); // Make sure all data is received
    });
    return Promise.all(fetches);
}

