import OBR from "@owlbear-rodeo/sdk";
import { APP_KEY, asset } from "../config";
import { constants } from "../constants";
import type { Spell } from "../types/spells";
import { getSortedTargets, targetHighlightMetadataKey } from "../effectsTool";
import { MESSAGE_CHANNEL } from "./messageListener";

const library = [
    ["stillwater", "Stillwater", "music", "ambient"],
    ["silver-bell", "Silver Bell", "effect", "bell, magic"],
    ["low-knock", "Low Knock", "effect", "door, impact"],
    ["soft-sweep", "Soft Sweep", "effect", "wind, motion"],
] as const;
const spells = Object.fromEntries(library.map(([id, name, category, tags]): [string, Spell] => [
    id, { name, audio: { url: asset("audio/" + id + ".mp3"), category, tags, volume: .65, start: 0, end: null, loop: category === "music" } },
]));
export const spellIDs = Object.keys(spells);

export function getSpell(spellID: string, isGM: boolean = false): Spell|undefined {
    if (spellID.startsWith("$.")) {
        const localSpellID = spellID.substring(2);
        const spellJSON = localStorage.getItem(
            isGM ? `${APP_KEY}/spells/${localSpellID}` : `${APP_KEY}/spells/${OBR.room.id}/${localSpellID}`
        );
        if (spellJSON == undefined) {
            return undefined;
        }
        const spell = JSON.parse(spellJSON);
        return spell;
    }
    return spells[spellID];
}

export async function getAllSpellNames(): Promise<string[]> {
    const metadata = await OBR.scene.getMetadata();
    const spellList = (metadata[constants.SPELL_LIST_METADATA_KEY] ?? []) as string[];
    return [...spellIDs, ...spellList.map(spell => `$.${spell}`)];
}


export async function doSpell(spellID: string, playerID: string, isGM: boolean) {
    const spell = getSpell(spellID, isGM);
    if (!spell) {
        await OBR.notification.show("This sound is unavailable.");
        return;
    }
    const source = await OBR.scene.isReady() ? (await getSortedTargets())[0]?.position : undefined;
    await OBR.broadcast.sendMessage(MESSAGE_CHANNEL, {
        instructions: [{ type: "effect", id: spellID, effectProperties: { source } }],
        spellData: { name: spell.name, caster: playerID },
    }, { destination: "ALL" });
    if (source) await OBR.scene.local.deleteItems((await OBR.scene.local.getItems()).filter(item => item.metadata[targetHighlightMetadataKey] !== undefined).map(item => item.id));
}
