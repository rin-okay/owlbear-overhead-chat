import OBR from "@owlbear-rodeo/sdk";
import { APP_KEY } from "../config";
import { log_error } from "../logging";
import { waitMs } from "../utils";
import type { ActiveEffect, Control, EffectInstruction, MessageType } from "../types/messageListener";
import { getSpell } from "./spells";
import { ACTIVE_EFFECTS, AUDIO_SETTINGS, PREFETCH, prefetchSamples, prefetchSound, watchSceneAudio } from "./audio";
import { GLOBAL_STORAGE_KEYS, getGlobalSettingsValue } from "../components/Settings/settings";

export const MESSAGE_CHANNEL = APP_KEY + "/effects";
export const CONTROL_CHANNEL = APP_KEY + "/control";
let work = Promise.resolve();

function enqueue(task: () => Promise<void>) {
    work = work.then(task).catch(log_error);
    return work;
}

async function authority(connectionId?: string) {
    const [id, role, self, party] = await Promise.all([
        OBR.player.getId(), OBR.player.getRole(), OBR.player.getConnectionId(), OBR.party.getPlayers(),
    ]);
    const players = [{ id, connectionId: self, role }, ...party.filter(player => player.connectionId !== self)];
    const gm = players.filter(player => player.role === "GM")
        .sort((a, b) => a.id.localeCompare(b.id) || a.connectionId.localeCompare(b.connectionId))[0];
    return { host: gm?.connectionId === self, actor: players.find(player => player.connectionId === (connectionId ?? self)), self };
}

function read(metadata: Record<string, unknown>): ActiveEffect[] {
    return (metadata[ACTIVE_EFFECTS] as ActiveEffect[] | undefined) ?? [];
}

export function validClip(settings: Pick<ActiveEffect, "volume" | "start" | "end" | "loop">) {
    return typeof settings.loop === "boolean" && Number.isFinite(settings.volume) && settings.volume >= 0 && settings.volume <= 1 &&
        Number.isFinite(settings.start) && settings.start >= 0 &&
        (settings.end === null || (Number.isFinite(settings.end) && settings.end > settings.start));
}

export function publicAudioURL(value: string) {
    if (value.length > 1200) throw Error("The audio URL is too long.");
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) throw Error("Use a public HTTPS audio URL.");
    if (url.hostname === "www.dropbox.com" || url.hostname === "dropbox.com") {
        url.searchParams.delete("dl");
        url.searchParams.set("raw", "1");
    }
    return url.href;
}

function requestSound(instruction: EffectInstruction, caster: string): ActiveEffect | undefined {
    if (instruction?.type !== "effect" || typeof instruction.id !== "string" || instruction.id.length > 100) return;
    const spell = getSpell(instruction.id, true);
    if (!spell || !validClip(spell.audio)) return;
    const sound = { ...spell.audio, url: publicAudioURL(spell.audio.url) };
    const duration = instruction.duration;
    if (typeof duration === "number" && Number.isFinite(duration) && duration > 0) {
        sound.end = Math.min(sound.end ?? Infinity, sound.start + duration / 1000);
    }
    let repetitions: number | undefined;
    if (typeof instruction.loops === "number" && Number.isInteger(instruction.loops)) {
        if (instruction.loops < 0) sound.loop = true;
        else if (instruction.loops > 0) {
            sound.loop = false;
            repetitions = Math.min(instruction.loops, 30);
        }
    }
    const point = instruction.effectProperties?.source;
    const source = point && Number.isFinite(point.x) && Number.isFinite(point.y) ? { x: point.x, y: point.y } : undefined;
    return { ...sound, name: spell.name, id: crypto.randomUUID(), caster, at: Date.now() + 100, offset: 0, visible: true, repetitions, source };
}

export function applyControl(entry: ActiveEffect, control: Control, now = Date.now()): ActiveEffect | undefined {
    switch (control.action) {
        case "delete": return;
        case "finish": return entry.at === control.at ? undefined : entry;
        case "hide": return { ...entry, visible: !entry.visible };
        case "pause": return entry.at === null ? entry : { ...entry, offset: entry.offset + Math.max(0, now - entry.at) / 1000, at: null };
        case "resume": return entry.at === null ? { ...entry, at: now } : entry;
        case "edit": {
            const settings = control.settings;
            if (!settings || !validClip(settings)) return entry;
            const { volume, start, end, loop } = settings;
            const reset = start !== entry.start || end !== entry.end || loop !== entry.loop;
            return { ...entry, volume, start, end, loop, ...(reset ? { at: entry.at === null ? null : now, offset: 0, repetitions: undefined } : {}) };
        }
        default: return entry;
    }
}

export function setupMessageListener() {
    const engine = watchSceneAudio(entry => {
        void enqueue(async () => {
            if (!(await authority()).host || entry.loop) return;
            await control({ id: entry.id, action: "finish", at: entry.at });
        });
    });

    async function write(entries: ActiveEffect[]) {
        await OBR.room.setMetadata({ [ACTIVE_EFFECTS]: entries });
        engine.render(entries);
    }

    async function control(request: Control) {
        const previous = read(await OBR.room.getMetadata());
        const next = previous.flatMap(entry => entry.id === request.id ? applyControl(entry, request) ?? [] : entry);
        if (next.length !== previous.length || next.some((entry, i) => entry !== previous[i])) await write(next);
    }

    prefetchSamples();
    OBR.room.onMetadataChange(metadata => engine.render(read(metadata)));
    void OBR.room.getMetadata().then(metadata => engine.render(read(metadata))).catch(log_error);
    OBR.broadcast.onMessage(AUDIO_SETTINGS, () => engine.settingsChanged());
    OBR.broadcast.onMessage(PREFETCH, async ({ data, connectionId }) => {
        const self = await OBR.player.getConnectionId();
        if (connectionId !== self || typeof data !== "string") return;
        const clip = getSpell(data, (await OBR.player.getRole()) === "GM");
        if (clip) prefetchSound(clip.audio.url);
    });
    OBR.broadcast.onMessage(CONTROL_CHANNEL, async ({ data, connectionId }) => {
        const request = data as Control;
        if (typeof request?.id !== "string" || request.action === "finish") return;
        await enqueue(async () => {
            const { host, actor } = await authority(connectionId);
            if (host && actor?.role === "GM") await control(request);
        });
    });

    return OBR.broadcast.onMessage(MESSAGE_CHANNEL, async message => {
        const messageData = message.data as MessageType;
        if (!Array.isArray(messageData?.instructions) || messageData.instructions.length > 16) {
            log_error("Malformed message: message.instructions must contain up to 16 instructions.");
            return;
        }
        try {
            const { host, actor } = await authority(message.connectionId);
            if (!host || !actor) return;
            if (actor.role !== "GM" && (!await OBR.scene.isReady() ||
                !await getGlobalSettingsValue(GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS))) return;
            await Promise.allSettled(messageData.instructions.map(async instruction => {
                if (typeof instruction?.delay === "number" && Number.isFinite(instruction.delay)) {
                    await waitMs(Math.max(0, Math.min(instruction.delay, 30000)));
                }
                await enqueue(async () => {
                    const sound = requestSound(instruction, actor.id);
                    if (!sound) return;
                    const entries = read(await OBR.room.getMetadata());
                    const keep = sound.category === "music" ? entries.filter(entry => entry.category !== "music") : entries;
                    await write([...keep.slice(-19), sound]);
                });
            }));
        } catch (error) {
            log_error(error);
        }
    });
}
