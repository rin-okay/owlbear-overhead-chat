import OBR from "@owlbear-rodeo/sdk";
import { APP_KEY } from "../config";
import { audioTokens, getAuto, listenerOf, PLAY_RULE } from "../auto/model";
import { appendCue, reaches } from "../auto/audience";
import { evaluateMovement, reconcileScene, startRule, watchTriggers } from "../auto/playback";
import { LIBRARY_CHANGED } from "./localSpells";
import { isSunoPage, sunoEmbedURL } from "../suno";
import { log_error } from "../logging";
import { waitMs } from "../utils";
import type { ActiveEffect, Control, EffectInstruction, MessageType } from "../types/messageListener";
import { getSpell } from "./spells";
import { ACTIVE_EFFECTS, AUDIO_SETTINGS, PREFETCH, prefetchSamples, prefetchSound, watchSceneAudio } from "./audio";
import { GLOBAL_STORAGE_KEYS, getGlobalSettingsValue } from "../components/Settings/settings";

export const MESSAGE_CHANNEL = APP_KEY + "/effects";
export const CONTROL_CHANNEL = APP_KEY + "/control";
let work = Promise.resolve();

function enqueue(task: () => Promise<void>) {
    work = work.then(task).catch(log_error);
    return work;
}

async function authority(connectionId?: string) {
    const [id, role, self, party] = await Promise.all([
        OBR.player.getId(), OBR.player.getRole(), OBR.player.getConnectionId(), OBR.party.getPlayers(),
    ]);
    const players = [{ id, connectionId: self, role }, ...party.filter(player => player.connectionId !== self)];
    const gm = players.filter(player => player.role === "GM")
        .sort((a, b) => a.id.localeCompare(b.id) || a.connectionId.localeCompare(b.connectionId))[0];
    return { host: gm?.connectionId === self, actor: players.find(player => player.connectionId === (connectionId ?? self)), self };
}

function read(metadata: Record<string, unknown>): ActiveEffect[] {
    return (metadata[ACTIVE_EFFECTS] as ActiveEffect[] | undefined) ?? [];
}

export function validClip(settings: Pick<ActiveEffect, "volume" | "start" | "end" | "loop">) {
    return typeof settings.loop === "boolean" && Number.isFinite(settings.volume) && settings.volume >= 0 && settings.volume <= 1 &&
        Number.isFinite(settings.start) && settings.start >= 0 &&
        (settings.end === null || (Number.isFinite(settings.end) && settings.end > settings.start));
}

export function publicAudioURL(value: string) {
    if (value.length > 1200) throw Error("The audio URL is too long.");
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) throw Error("Use a public HTTPS audio URL.");
    if (isSunoPage(url)) {
        const embed = sunoEmbedURL(url.href);
        if (!embed) throw Error("Paste the Suno embed or song URL with its full song ID.");
        return embed;
    }
    if (url.hostname === "www.dropbox.com" || url.hostname === "dropbox.com") {
        url.searchParams.delete("dl");
        url.searchParams.set("raw", "1");
    }
    return url.href;
}

function requestSound(instruction: EffectInstruction, caster: string): ActiveEffect | undefined {
    if (instruction?.type !== "effect" || typeof instruction.id !== "string" || instruction.id.length > 100) return;
    const spell = getSpell(instruction.id, true);
    if (!spell || !validClip(spell.audio)) return;
    const sound = { ...spell.audio, url: publicAudioURL(spell.audio.url) };
    const embed = sunoEmbedURL(sound.url);
    if (embed) return {
        ...sound, category: "music", name: spell.name, id: crypto.randomUUID(), caster,
        at: Date.now(), offset: 0, visible: true,
    };
    const duration = instruction.duration;
    if (typeof duration === "number" && Number.isFinite(duration) && duration > 0) {
        sound.end = Math.min(sound.end ?? Infinity, sound.start + duration / 1000);
    }
    let repetitions: number | undefined;
    if (typeof instruction.loops === "number" && Number.isInteger(instruction.loops)) {
        if (instruction.loops < 0) sound.loop = true;
        else if (instruction.loops > 0) {
            sound.loop = false;
            repetitions = Math.min(instruction.loops, 30);
        }
    }
    const point = instruction.effectProperties?.source;
    const source = point && Number.isFinite(point.x) && Number.isFinite(point.y) ? { x: point.x, y: point.y } : undefined;
    return { ...sound, name: spell.name, id: crypto.randomUUID(), caster, at: Date.now() + 100, offset: 0, visible: true, repetitions, source };
}

export function applyControl(entry: ActiveEffect, control: Control, now = Date.now()): ActiveEffect | undefined {
    if (control.action === "mute-token" || control.action === "remove-token") {
        const audience = entry.audience;
        if (!audience?.listeners.some(listener => listener.tokenId === control.tokenId)) return entry;
        const listeners = control.action === "remove-token"
            ? audience.listeners.filter(listener => listener.tokenId !== control.tokenId)
            : audience.listeners.map(listener => listener.tokenId === control.tokenId ? { ...listener, muted: !listener.muted } : listener);
        return listeners.length ? { ...entry, audience: { mode: control.action === "remove-token" ? "list" : audience.mode, listeners } } : undefined;
    }
    if (sunoEmbedURL(entry.url) && control.action !== "delete" && control.action !== "hide") return entry;
    switch (control.action) {
        case "delete": return;
        case "finish": return entry.at === control.at ? undefined : entry;
        case "hide": return { ...entry, visible: !entry.visible };
        case "pause": return entry.at === null ? entry : { ...entry, offset: entry.offset + Math.max(0, now - entry.at) / 1000, at: null };
        case "resume": return entry.at === null ? { ...entry, at: now } : entry;
        case "edit": {
            const settings = control.settings;
            if (!settings || !validClip(settings)) return entry;
            const { volume, start, end, loop } = settings;
            const reset = start !== entry.start || end !== entry.end || loop !== entry.loop;
            return { ...entry, volume, start, end, loop, ...(reset ? { at: entry.at === null ? null : now, offset: 0, repetitions: undefined } : {}) };
        }
        default: return entry;
    }
}

export function setupMessageListener() {
    const engine = watchSceneAudio(entry => {
        if (entry.loop || entry.at === null) return;
        void OBR.broadcast.sendMessage(CONTROL_CHANNEL, {
            id: entry.id, action: "finish", at: entry.at,
        } satisfies Control, { destination: "ALL" }).catch(log_error);
    });

    async function write(entries: ActiveEffect[]) {
        await OBR.room.setMetadata({ [ACTIVE_EFFECTS]: entries });
        engine.render(entries, await OBR.player.getId());
    }

    async function control(request: Control) {
        const previous = read(await OBR.room.getMetadata());
        const next = previous.flatMap(entry => entry.id === request.id ? applyControl(entry, request) ?? [] : entry);
        if (next.length !== previous.length || next.some((entry, i) => entry !== previous[i])) await write(next);
    }

    let currentRole: "GM" | "PLAYER" | undefined;
    void OBR.player.getRole().then(role => {
        currentRole = role;
        if (role === "GM") triggers.refreshAuthority();
    }).catch(log_error);
    OBR.player.onChange(player => {
        if (currentRole === player.role) return;
        currentRole = player.role;
        if (currentRole === "GM") triggers.refreshAuthority();
    });
    const triggers = watchTriggers((config, current, previous) => {
        if (currentRole === "PLAYER") return;
        if (config && previous && !config.rules.length && JSON.stringify(current.map(listenerOf)) ===
            JSON.stringify(previous.map(listenerOf))) return;
        void enqueue(async () => {
            const { host, actor } = await authority();
            if (!host || !actor) return;
            const entries = read(await OBR.room.getMetadata());
            const filtered = config ? reconcileScene(entries, config, current, previous) : entries.filter(entry => !entry.ruleId);
            const next = config && previous ? evaluateMovement(filtered, config, previous, current, rule => {
                const cue = requestSound({ type: "effect", id: rule.soundId }, actor.id);
                return cue && !sunoEmbedURL(cue.url) ? cue : undefined;
            }) : filtered;
            if (next.length !== entries.length || next.some((entry, index) => entry !== entries[index])) await write(next);
        });
    }, config => {
        void OBR.player.getRole().then(role => {
            for (const id of new Set(config.rules.map(rule => rule.soundId))) {
                const cue = getSpell(id, role === "GM");
                if (cue && !sunoEmbedURL(cue.audio.url)) prefetchSound(publicAudioURL(cue.audio.url));
            }
        }).catch(log_error);
    });
    let partySignature: string | undefined;
    OBR.party.onChange(players => {
        const signature = players.filter(player => player.role === "GM").map(player => player.connectionId).sort().join(",");
        if (signature !== partySignature) triggers.refreshAuthority();
        partySignature = signature;
    });
    OBR.broadcast.onMessage(LIBRARY_CHANGED, () => triggers.refreshLibrary());
    OBR.broadcast.onMessage(PLAY_RULE, ({ data, connectionId }) => {
        const request = data as { ruleId?: string; tokenId?: string } | null;
        if (typeof request?.ruleId !== "string") return;
        void enqueue(async () => {
            const { host, actor } = await authority(connectionId);
            if (!host || actor?.role !== "GM" || !await OBR.scene.isReady()) return;
            const [metadata, items, room] = await Promise.all([OBR.scene.getMetadata(), OBR.scene.items.getItems(), OBR.room.getMetadata()]);
            const config = getAuto(metadata);
            const rule = config.rules.find(item => item.id === request.ruleId);
            const trigger = config.triggers.find(item => item.id === rule?.triggerId);
            if (!rule || !trigger) return;
            const tokens = audioTokens(items);
            const token = tokens.find(item => item.tokenId === request.tokenId);
            const previous = read(room);
            const next = startRule(previous, rule, token, tokens, token?.position ?? trigger.points[0], () => {
                const cue = requestSound({ type: "effect", id: rule.soundId }, actor.id);
                return cue && !sunoEmbedURL(cue.url) ? cue : undefined;
            });
            if (next !== previous) await write(next);
        });
    });
    prefetchSamples();
    void OBR.player.getId().then(userId => {
        OBR.room.onMetadataChange(metadata => engine.render(read(metadata), userId));
        return OBR.room.getMetadata().then(metadata => engine.render(read(metadata), userId));
    }).catch(log_error);
    OBR.broadcast.onMessage(AUDIO_SETTINGS, () => engine.settingsChanged());
    OBR.broadcast.onMessage(PREFETCH, async ({ data, connectionId }) => {
        const self = await OBR.player.getConnectionId();
        if (connectionId !== self || typeof data !== "string") return;
        const clip = getSpell(data, (await OBR.player.getRole()) === "GM");
        if (clip && !sunoEmbedURL(clip.audio.url)) prefetchSound(clip.audio.url);
    });
    OBR.broadcast.onMessage(CONTROL_CHANNEL, async ({ data, connectionId }) => {
        const request = data as Control;
        if (typeof request?.id !== "string") return;
        await enqueue(async () => {
            const { host, actor } = await authority(connectionId);
            if (!host || !actor) return;
            if (request.action === "finish") {
                const entry = read(await OBR.room.getMetadata()).find(item => item.id === request.id);
                if (!entry || entry.loop || entry.at === null || entry.at !== request.at || !reaches(entry, actor.id) || sunoEmbedURL(entry.url)) return;
                await control(request);
            } else if (actor.role === "GM") await control(request);
        });
    });

    return OBR.broadcast.onMessage(MESSAGE_CHANNEL, async message => {
        const messageData = message.data as MessageType;
        if (!Array.isArray(messageData?.instructions) || messageData.instructions.length > 16) {
            log_error("Malformed message: message.instructions must contain up to 16 instructions.");
            return;
        }
        try {
            const { host, actor } = await authority(message.connectionId);
            if (!host || !actor) return;
            if (actor.role !== "GM" && (!await OBR.scene.isReady() ||
                !await getGlobalSettingsValue(GLOBAL_STORAGE_KEYS.PLAYERS_CAN_CAST_SPELLS))) return;
            await Promise.allSettled(messageData.instructions.map(async instruction => {
                if (typeof instruction?.delay === "number" && Number.isFinite(instruction.delay)) {
                    await waitMs(Math.max(0, Math.min(instruction.delay, 30000)));
                }
                await enqueue(async () => {
                    const sound = requestSound(instruction, actor.id);
                    if (!sound) return;
                    const sceneReady = await OBR.scene.isReady();
                    const listeners = sceneReady ? audioTokens(await OBR.scene.items.getItems()).map(listenerOf) : [];
                    if (!listeners.length) {
                        if (actor.connectionId === (await OBR.player.getConnectionId())) {
                            await OBR.notification.show("Enable audio on a character token first.");
                        }
                        return;
                    }
                    const entries = read(await OBR.room.getMetadata());
                    const forced = sound.category === "music" && instruction.force === true;
                    const keep = sound.category !== "music" ? entries
                        : entries.filter(entry => entry.category !== "music" || entry.ruleId || Boolean(entry.forced) !== forced);
                    await write(appendCue(keep, { ...sound, forced, audience: { mode: "all", listeners } }));
                });
            }));
        } catch (error) {
            log_error(error);
        }
    });
}
