import type { Sound } from "../types/spells";

export const LIBRARY_FOLDERS = {
    effect: {
        label: "Sound effects",
        folders: [
            { id: "ambient-loops", label: "Ambient loops" },
            { id: "combat", label: "Combat" },
            { id: "others", label: "Others" },
        ],
    },
    music: {
        label: "Music",
        folders: [
            { id: "combat", label: "Combat" },
            { id: "ambient", label: "Ambient" },
            { id: "town-themes", label: "Town themes" },
        ],
    },
} as const;

export function soundTags(tags: string): string[] {
    return [...new Set((tags.match(/\([^()]+\)|[^,\n()]+/g) ?? []).map(tag => tag.trim().replace(/^\((.*)\)$/, "$1").trim()).filter(Boolean))];
}

export function soundFolder(sound: Pick<Sound, "category" | "folder" | "tags" | "loop">) {
    const folders = LIBRARY_FOLDERS[sound.category].folders;
    if (folders.some(folder => folder.id === sound.folder)) return sound.folder!;
    const tags = soundTags(sound.tags).map(tag => tag.toLowerCase());
    if (tags.includes("combat")) return "combat";
    if (sound.category === "music") {
        return tags.some(tag => ["town", "town theme", "town themes"].includes(tag)) ? "town-themes" : "ambient";
    }
    return sound.loop ? "ambient-loops" : "others";
}

export function formatDuration(seconds: number) {
    const rounded = Math.max(1, Math.round(seconds));
    const hours = Math.floor(rounded / 3600);
    const minutes = Math.floor(rounded / 60) % 60;
    const remainder = String(rounded % 60).padStart(2, "0");
    return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${remainder}` : `${minutes}:${remainder}`;
}
