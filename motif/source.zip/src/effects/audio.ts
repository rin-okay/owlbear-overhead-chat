import OBR, { buildShape, type Vector2 } from "@owlbear-rodeo/sdk";
import { audible, musicSuppressions, reaches } from "../auto/audience";
import { APP_KEY } from "../config";
import { sunoEmbedURL } from "../suno";
import { waitMs } from "../utils";
import type { ActiveEffect } from "../types/messageListener";
import { getSpell, spellIDs } from "./spells";
import { prefetchAssets } from "./effects";

export const ACTIVE_EFFECTS = APP_KEY + "/active-effects";
export const AUDIO_SETTINGS = APP_KEY + "/audio-settings";
export const AUDIO_RETRY = APP_KEY + "/audio-retry";
export const audioBlockedKey = () => JSON.stringify([AUDIO_RETRY, OBR.room.id, OBR.player.id]);
export function audioIsBlocked() {
    try { return sessionStorage.getItem(audioBlockedKey()) === "1"; } catch { return false; }
}
export const PREFETCH = APP_KEY + "/prefetch";
const samples = new Map<string, Promise<Blob | undefined>>();

export function prefetchSound(url: string) {
    if (samples.has(url)) return;
    if (samples.size >= 12) {
        const oldest = samples.keys().next().value;
        if (oldest) samples.delete(oldest);
    }
    samples.set(url, prefetchAssets([url]).then(([blob]) => blob).catch(() => {
        samples.delete(url);
        return undefined;
    }));
}

export function prefetchSamples() {
    for (const id of spellIDs) {
        const url = getSpell(id)?.audio.url;
        if (url) prefetchSound(url);
    }
}

export function clipTime(entry: ActiveEffect, duration: number, now = Date.now()) {
    const elapsed = entry.offset + (entry.at === null ? 0 : Math.max(0, now - entry.at) / 1000);
    const end = Math.min(entry.end ?? Infinity, Number.isFinite(duration) ? duration : Infinity);
    const length = end - entry.start;
    const repeats = entry.loop ? Infinity : entry.repetitions ?? 1;
    if (length <= 0 || elapsed >= length * repeats) return undefined;
    return entry.start + (Number.isFinite(length) ? elapsed % length : elapsed);
}

type Channel = {
    entry: ActiveEffect;
    audio: HTMLAudioElement;
    align: boolean;
    completed: boolean;
    repeats: number;
    blob?: string;
    starting?: boolean;
    blocked?: boolean;
    retrying?: boolean;
    wake?: number;
    audible: boolean;
};

export function watchSceneAudio(onFinish: (entry: ActiveEffect) => void) {
    const channels = new Map<string, Channel>();
    const seen = new Map<string, string>();
    let mix = readMix();
    let reportedBlocked: boolean | undefined;

    function updateBlocked() {
        const blocked = [...channels.values()].some(voice =>
            (voice.blocked || voice.retrying) && voice.audible && !voice.completed && voice.entry.at !== null);
        if (blocked === reportedBlocked) return;
        reportedBlocked = blocked;
        try {
            if (blocked) sessionStorage.setItem(audioBlockedKey(), "1");
            else sessionStorage.removeItem(audioBlockedKey());
        } catch {}
        void OBR.action.setBadgeText(blocked ? "!" : "").catch(console.warn);
    }

    function readMix() {
        try {
            const saved = JSON.parse(localStorage.getItem(AUDIO_SETTINGS) ?? "{}");
            return { music: Number.isFinite(saved.music) ? saved.music : .7, effect: Number.isFinite(saved.effect) ? saved.effect : .85 };
        } catch { return { music: .7, effect: .85 }; }
    }

    function updateMix({ audio, entry, audible }: Channel) {
        audio.volume = Math.max(0, Math.min(1, entry.volume * mix[entry.category]));
        audio.muted = !audible;
        audio.loop = entry.loop && entry.start === 0 && (entry.end === null || entry.end >= audio.duration);
    }

    function naturalEnd(voice: Channel) {
        if (voice.completed) return;
        voice.completed = true;
        voice.retrying = false;
        voice.audio.pause();
        updateBlocked();
        onFinish(voice.entry);
    }

    function play(voice: Channel) {
        const { audio, entry } = voice;
        if (channels.get(entry.id) !== voice || entry.at === null || voice.completed || voice.starting ||
            voice.blocked || audio.readyState < 3 || audio.seeking || !audio.paused) return;
        if (entry.at > Date.now()) {
            voice.wake ??= window.setTimeout(() => { voice.wake = undefined; play(voice); }, entry.at - Date.now());
            return;
        }
        if (voice.align) {
            const position = clipTime(entry, audio.duration);
            if (position === undefined) {
                naturalEnd(voice);
                return;
            }
            voice.align = false;
            const length = Math.min(entry.end ?? audio.duration, audio.duration) - entry.start;
            if (Number.isFinite(length) && length > 0 && !entry.loop) {
                const elapsed = entry.offset + Math.max(0, Date.now() - entry.at) / 1000;
                voice.repeats = Math.max(1, (entry.repetitions ?? 1) - Math.floor(elapsed / length));
            }
            if (Math.abs(audio.currentTime - position) > .075) audio.currentTime = position;
            if (audio.seeking) return;
        }
        voice.starting = true;
        void audio.play().then(() => {
            voice.blocked = false;
            voice.retrying = false;
            updateBlocked();
        }).catch((error: DOMException) => {
            voice.retrying = false;
            if (error.name === "NotAllowedError" && channels.get(entry.id) === voice) voice.blocked = true;
            updateBlocked();
        }).finally(() => {
            voice.starting = false;
            if (voice.align && voice.entry !== entry) play(voice);
        });
    }

    function boundary(voice: Channel) {
        const { entry, audio } = voice;
        if (voice.completed || voice.align || entry.at === null || audio.seeking || audio.loop ||
            (!audio.ended && (entry.end === null || audio.currentTime < entry.end))) return;
        if (!entry.loop && --voice.repeats <= 0) {
            naturalEnd(voice);
            return;
        }
        audio.currentTime = entry.start;
        play(voice);
    }

    function create(entry: ActiveEffect, canHear: boolean) {
        const audio = new Audio();
        audio.preload = "auto";
        const voice = { audio, entry, audible: canHear, align: true, completed: false, repeats: entry.repetitions ?? 1 } as Channel;
        channels.set(entry.id, voice);
        audio.addEventListener("canplay", () => play(voice));
        audio.addEventListener("seeked", () => play(voice));
        audio.addEventListener("loadedmetadata", () => updateMix(voice));
        audio.addEventListener("ended", () => boundary(voice));
        audio.addEventListener("timeupdate", () => boundary(voice));
        audio.addEventListener("error", () => {
            if (channels.get(entry.id) === voice) void OBR.notification.show("Motif couldn’t load " + entry.name + ".");
        });
        void Promise.resolve(samples.get(entry.url)).then(blob => {
            if (channels.get(entry.id) !== voice) return;
            if (blob) voice.blob = URL.createObjectURL(blob);
            audio.src = voice.blob ?? entry.url;
        });
        return voice;
    }

    function remove(id: string, voice: Channel) {
        channels.delete(id);
        window.clearTimeout(voice.wake);
        voice.audio.pause();
        voice.audio.removeAttribute("src");
        voice.audio.load();
        if (voice.blob) URL.revokeObjectURL(voice.blob);
    }

    async function ripple(position: Vector2, at: number) {
        if (Date.now() - at > 1800 || !await OBR.scene.isReady()) return;
        let active = true;
        const unsubscribe = OBR.scene.onReadyChange(() => { active = false; });
        const dpi = await OBR.scene.grid.getDpi();
        const ring = buildShape().shapeType("CIRCLE").position(position).width(dpi / 4).height(dpi / 4)
            .name("Motif ripple").locked(true).disableHit(true).layer("POINTER").fillOpacity(0)
            .strokeColor("#c7b6f8").strokeWidth(dpi / 28).build();
        try {
            if (!active) return;
            await OBR.scene.local.addItems([ring]);
            for (let i = 1; i <= 6 && active; i++) {
                await waitMs(75);
                if (!active) break;
                await OBR.scene.local.updateItems<typeof ring>([ring.id], ([item]) => {
                    if (!item) return;
                    item.width = item.height = dpi * (.25 + i * .17);
                    item.style.strokeOpacity = 1 - i / 7;
                });
            }
        } finally {
            unsubscribe();
            if (active) await OBR.scene.local.deleteItems([ring.id]);
        }
    }

    function render(entries: ActiveEffect[], userId: string) {
        const media = entries.filter(entry => !sunoEmbedURL(entry.url) && reaches(entry, userId));
        const present = new Set(media.map(entry => entry.id));
        for (const [id, voice] of channels) if (!present.has(id)) {
            remove(id, voice);
            seen.delete(id);
        }
        const suppressed = musicSuppressions(entries);
        for (const entry of media) {
            const canHear = audible(entry, userId, suppressed.get(entry.id));
            const flash = entry.ripple;
            const marker = flash?.id ?? entry.id;
            if (canHear && seen.get(entry.id) !== marker) {
                seen.set(entry.id, marker);
                if (flash && (!flash.tokenId || entry.audience?.listeners.some(listener =>
                    listener.tokenId === flash.tokenId && listener.userId === userId && !listener.muted))) {
                    void ripple(flash.position, flash.at).catch(console.warn);
                } else if (!flash && entry.source && entry.at !== null) {
                    void ripple(entry.source, entry.at).catch(console.warn);
                }
            }
            const voice = channels.get(entry.id) ?? create(entry, canHear);
            const old = voice.entry;
            voice.entry = entry;
            voice.audible = canHear;
            if (old.at !== entry.at || old.offset !== entry.offset || old.start !== entry.start || old.end !== entry.end || old.loop !== entry.loop) {
                voice.align = true;
                voice.completed = false;
                voice.repeats = entry.repetitions ?? 1;
                voice.audio.pause();
            }
            updateMix(voice);
            if (entry.at === null) voice.audio.pause();
            else play(voice);
        }
        updateBlocked();
    }

    function retryBlocked() {
        for (const voice of channels.values()) {
            if (!voice.blocked || voice.entry.at === null || voice.completed) continue;
            voice.blocked = false;
            voice.retrying = true;
            voice.align = true;
            play(voice);
        }
    }

    function retryWhenVisible() {
        if (document.visibilityState === "visible") retryBlocked();
    }

    window.addEventListener("focus", retryBlocked);
    document.addEventListener("visibilitychange", retryWhenVisible);
    const timer = window.setInterval(() => {
        for (const voice of channels.values()) if (voice.entry.end !== null && !voice.audio.paused) boundary(voice);
    }, 60);
    window.addEventListener("pagehide", () => {
        window.clearInterval(timer);
        window.removeEventListener("focus", retryBlocked);
        document.removeEventListener("visibilitychange", retryWhenVisible);
        for (const [id, voice] of channels) remove(id, voice);
    }, { once: true });
    return {
        render, retryBlocked,
        settingsChanged() {
            mix = readMix();
            for (const voice of channels.values()) updateMix(voice);
        },
    };
}
