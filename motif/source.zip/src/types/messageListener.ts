import type { Vector2 } from "@owlbear-rodeo/sdk";
import type { Sound } from "./spells";

export interface EffectInstruction {
    type: "effect";
    id: string;
    delay?: number;
    duration?: number;
    loops?: number;
    effectProperties?: { source?: Vector2 };
}

export interface MessageType {
    instructions: EffectInstruction[];
    spellData?: { name: string; caster: string };
}
export interface ActiveEffect extends Sound {
    id: string;
    name: string;
    caster: string;
    at: number | null;
    offset: number;
    visible: boolean;
    repetitions?: number;
    source?: Vector2;
}

export type Control = {
    id: string;
    action: "hide" | "pause" | "resume" | "delete" | "finish" | "edit";
    at?: number | null;
    settings?: Pick<Sound, "volume" | "start" | "end" | "loop">;
};
