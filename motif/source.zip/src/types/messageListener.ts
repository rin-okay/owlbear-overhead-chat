import type { Vector2 } from "@owlbear-rodeo/sdk";
import type { Listener } from "../auto/model";
import type { Sound } from "./spells";

export interface EffectInstruction {
    type: "effect";
    id: string;
    delay?: number;
    duration?: number;
    loops?: number;
    force?: boolean;
    listenerTokenIds?: string[];
    effectProperties?: { source?: Vector2 };
}

export interface MessageType {
    instructions: EffectInstruction[];
    spellData?: { name: string; caster: string };
}
export interface ActiveEffect extends Sound {
    id: string;
    name: string;
    caster: string;
    at: number | null;
    offset: number;
    visible: boolean;
    repetitions?: number;
    source?: Vector2;
    ripple?: { id: string; at: number; position: Vector2; tokenId?: string };
    audience?: { mode: "all" | "list"; listeners: Listener[] };
    ruleId?: string;
    forced?: boolean;
    targeted?: boolean;
    stopMusicTags?: string[];
    overheadLoop?: boolean;
    stopAt?: number;
}

export type Control = {
    id: string;
    action: "hide" | "pause" | "resume" | "delete" | "finish" | "edit" | "mute-token" | "remove-token";
    tokenId?: string;
    at?: number | null;
    settings?: Pick<Sound, "volume" | "start" | "end" | "loop">;
};
