export interface Sound {
    url: string;
    category: "music" | "effect";
    folder?: string;
    duration?: number;
    volume: number;
    start: number;
    end: number | null;
    loop: boolean;
    tags: string;
}

export interface Spell {
    name: string;
    audio: Sound;
}
