import "./index.css";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { StrictMode } from "react";
import { darkTheme } from "./config/theme";
import { BaseOBRProvider } from "./react-obr/providers";
import NameTrigger from "./views/NameTrigger";
import Main from "./views/Main";
import SunoPlayer from "./views/SunoPlayer";
import OBR from "@owlbear-rodeo/sdk";
import SpellSelectionPopover from "./views/SpellSelectionPopover";
import { createRoot } from "react-dom/client";
import { asset } from "./config";

function ExtensionMultiplexer() {
    const panel = new URLSearchParams(window.location.search).get("panel");
    return <ThemeProvider theme={darkTheme}>
        <CssBaseline/>
        {OBR.isAvailable ? <BaseOBRProvider>{panel === "select" ? <SpellSelectionPopover/> : panel === "suno" ? <SunoPlayer/> : panel === "name-trigger" ? <NameTrigger/> : <Main/>}</BaseOBRProvider> :
            <main className="motif-panel panel-content"><h1>Motif</h1>
                <p>Play music and sound effects together in Owlbear Rodeo.</p>
                <a href={asset("manifest.json")}>Owlbear Rodeo manifest</a>
            </main>}
    </ThemeProvider>;
}

createRoot(document.getElementById("root")!).render(<StrictMode><ExtensionMultiplexer/></StrictMode>);
