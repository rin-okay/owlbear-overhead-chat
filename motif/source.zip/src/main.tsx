import "./index.css";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { StrictMode, useEffect, useState } from "react";
import { darkTheme, lightTheme } from "./config/theme";
import { BaseOBRProvider } from "./react-obr/providers";
import Main from "./views/Main";
import SunoPlayer from "./views/SunoPlayer";
import OBR from "@owlbear-rodeo/sdk";
import SpellSelectionPopover from "./views/SpellSelectionPopover";
import { createRoot } from "react-dom/client";
import { asset } from "./config";

function ExtensionMultiplexer() {
    const [themeMode, setThemeMode] = useState<"DARK" | "LIGHT">("DARK");
    const panel = new URLSearchParams(window.location.search).get("panel");
    useEffect(() => {
        let unsubscribe: (() => void) | undefined;
        let active = true;
        OBR.onReady(() => {
            if (!active) return;
            void OBR.theme.getTheme().then(theme => setThemeMode(theme.mode));
            unsubscribe = OBR.theme.onChange(theme => setThemeMode(theme.mode));
        });
        return () => { active = false; unsubscribe?.(); };
    }, []);
    return <ThemeProvider theme={themeMode === "DARK" ? darkTheme : lightTheme}>
        <CssBaseline/>
        {OBR.isAvailable ? <BaseOBRProvider>{panel === "select" ? <SpellSelectionPopover/> : panel === "suno" ? <SunoPlayer/> : <Main/>}</BaseOBRProvider> :
            <main className="motif-panel panel-content"><h1>Motif</h1>
                <p>Play music and sound effects together in Owlbear Rodeo.</p>
                <a href={asset("manifest.json")}>Owlbear Rodeo manifest</a>
            </main>}
    </ThemeProvider>;
}

createRoot(document.getElementById("root")!).render(<StrictMode><ExtensionMultiplexer/></StrictMode>);
